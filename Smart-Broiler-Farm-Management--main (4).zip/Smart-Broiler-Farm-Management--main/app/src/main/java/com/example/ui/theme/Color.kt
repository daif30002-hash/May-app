package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FarmGreenPrimary = Color(0xFF1B5E20)
val FarmGreenSecondary = Color(0xFF2E7D32)
val FarmGoldAccent = Color(0xFFF9A825)
val FarmOrange = Color(0xFFE65100)
val FarmDarkBg = Color(0xFF0F1411)
val FarmDarkSurface = Color(0xFF1B231E)
val FarmTextOnDark = Color(0xFFE8F5E9)

// Light Theme colors matching the 'Bold Typography' style
val FarmLightBg = Color(0xFFF8FAF9)
val FarmLightSurface = Color(0xFFFFFFFF)
val FarmLightBorder = Color(0xFFE2E8F0)
val FarmLightText = Color(0xFF0F172A)
