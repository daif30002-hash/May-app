package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.viewmodel.PoultryViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarnsScreen(
    viewModel: PoultryViewModel,
    barns: List<Barn>,
    records: List<DailyRecord>,
    weights: List<WeightSample>,
    expenses: List<Expense>
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    var showAddBarnDialog by remember { mutableStateOf(false) }
    var expandedBarnId by remember { mutableStateOf<Long?>(null) }

    // Dialog form triggers
    var recordTargetBarn by remember { mutableStateOf<Barn?>(null) }
    var weightTargetBarn by remember { mutableStateOf<Barn?>(null) }
    var expenseTargetBarn by remember { mutableStateOf<Barn?>(null) }

    // Role safety
    val canModify = viewModel.canInsertOrEdit()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        modifier = Modifier.testTag("barns_screen"),
        floatingActionButton = {
            if (canModify) {
                FloatingActionButton(
                    onClick = { showAddBarnDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("add_barn_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Barn", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                text = if (isAr) "إدارة عنابر الدواجن (نظام مغلق)" else "Poultry Barns (Closed System)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (isAr) "العنابر النشطة، تسجيل السير اليومي والأوزان والأرباح" else "Active barns, logs and growth monitoring",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            if (barns.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Warehouse, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isAr) "لا توجد عنابر مرصودة ومسجلة حالياً." else "No barns configured yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (canModify) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { showAddBarnDialog = true }) {
                                Text(if (isAr) "تسكين أول عنبر" else "Install First Barn")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(barns) { barn ->
                        val isExpanded = expandedBarnId == barn.id
                        val age = viewModel.getBarnAge(barn)
                        val mortality = viewModel.getBarnMortalityRate(barn, records)
                        val liveCount = viewModel.getBarnLiveCount(barn, records)
                        val occupancyRange = if (barn.capacity > 0) (liveCount.toDouble() / barn.capacity.toDouble()) * 100.0 else 0.0

                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("barn_card_${barn.id}"),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = if (isExpanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = barn.code,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isAr) "سلالة: ${barn.breedType} • العمر: $age يوم" else "Breed: ${barn.breedType} • Age: $age days",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { expandedBarnId = if (isExpanded) null else barn.id }) {
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = "Expand details"
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Barn quick metrics overview
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    QuickGridItem(if (isAr) "العدد الحالي" else "Live", "$liveCount / ${barn.startingChicks}")
                                    QuickGridItem(if (isAr) "نسبة الإشغال" else "Occupancy", String.format("%.1f%%", occupancyRange))
                                    QuickGridItem(if (isAr) "معدل النفوق" else "Mortality %", String.format("%.2f%%", mortality))
                                }

                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column {
                                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                                        
                                        // Specific actions row
                                        Text(
                                            text = if (isAr) "تسجيل وإدخال البيانات اليومية الحالية" else "Log current data inputs",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Button(
                                                onClick = { recordTargetBarn = barn },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                modifier = Modifier.weight(1f).testTag("log_daily_btn")
                                            ) {
                                                Icon(Icons.Default.BorderColor, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isAr) "سجل يومي" else "Daily Log", style = MaterialTheme.typography.bodySmall)
                                            }
                                            Button(
                                                onClick = { weightTargetBarn = barn },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                                modifier = Modifier.weight(1f).testTag("log_weight_btn")
                                            ) {
                                                Icon(Icons.Default.MonitorWeight, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isAr) "وزن عينة" else "Weighing", style = MaterialTheme.typography.bodySmall)
                                            }
                                            Button(
                                                onClick = { expenseTargetBarn = barn },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                                modifier = Modifier.weight(1f).testTag("log_expense_btn")
                                            ) {
                                                Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isAr) "نفقات" else "Expences", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // History log summary for this barn
                                        val barnRecords = records.filter { it.barnId == barn.id }.take(3)
                                        if (barnRecords.isNotEmpty()) {
                                            Text(
                                                text = if (isAr) "آخر السجلات المسجلة لهذا العنبر:" else "Last logs feed:",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            barnRecords.forEach { rec ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 4.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "• ${rec.date} (${if (isAr) "عمر" else "Age"} ${rec.ageDays} ${if (isAr) "يوم" else "days"})",
                                                        style = MaterialTheme.typography.bodySmall
                                                    )
                                                    Text(
                                                        text = "${if (isAr) "علف" else "Feed"}: ${rec.feedMorningQty + rec.feedEveningQty} كجم | ${if (isAr) "نافق" else "Dead"}: ${rec.mortalityMorning + rec.mortalityEvening}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }

                                        if (viewModel.canDelete()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            OutlinedButton(
                                                onClick = { viewModel.deleteBarn(barn) },
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (isAr) "حذف العنبر بالكامل" else "Delete Barn completely", style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Barn Dialog
    if (showAddBarnDialog) {
        var code by remember { mutableStateOf("") }
        var capacity by remember { mutableStateOf("10000") }
        var startingChicks by remember { mutableStateOf("10000") }
        var breedType by remember { mutableStateOf("Ross 308") }
        var startDate by remember { mutableStateOf(viewModel.getCurrentDateString()) }

        val breedsList = listOf("Ross 308", "Cobb 500", "Indian River")

        AlertDialog(
            onDismissRequest = { showAddBarnDialog = false },
            title = { Text(if (isAr) "تسكين عنبر جديد في المزرعة" else "Install New Barn") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text(if (isAr) "كود أو اسم العنبر" else "Barn Code / ID") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = capacity,
                        onValueChange = { capacity = it },
                        label = { Text(if (isAr) "السعة الإجمالية للعنبر" else "Barn Capacity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = startingChicks,
                        onValueChange = { startingChicks = it },
                        label = { Text(if (isAr) "عدد الكتاكيت في البداية" else "Starting chicks headcount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text(if (isAr) "تاريخ بداية الدورة (YYYY-MM-DD)" else "Cycle Begin Date") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Text(if (isAr) "نوع سلالة الكتاكيت:" else "Chicks Breed Category:", style = MaterialTheme.typography.labelMedium)
                    breedsList.forEach { b ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { breedType = b }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = breedType == b, onClick = { breedType = b })
                            Text(b, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (code.isNotBlank()) {
                            val capacityInt = capacity.toIntOrNull() ?: 10000
                            val chicksInt = startingChicks.toIntOrNull() ?: capacityInt
                            viewModel.saveBarn(
                                Barn(
                                    code = code,
                                    capacity = capacityInt,
                                    startingChicks = chicksInt,
                                    startDate = startDate,
                                    breedType = breedType
                                )
                            )
                            showAddBarnDialog = false
                        }
                    }
                ) {
                    Text(if (isAr) "حفظ والتسكين" else "Deploy Barn")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBarnDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }

    // Add Daily Record Dialog
    if (recordTargetBarn != null) {
        val barn = recordTargetBarn!!
        val autoAge = viewModel.getBarnAge(barn)

        var recordDate by remember { mutableStateOf(viewModel.getCurrentDateString()) }
        var feedMor by remember { mutableStateOf("150.0") }
        var feedEve by remember { mutableStateOf("150.0") }
        var waterLiters by remember { mutableStateOf("540.0") }
        var mortMor by remember { mutableStateOf("1") }
        var mortEve by remember { mutableStateOf("0") }
        var sold by remember { mutableStateOf("0") }
        var domestic by remember { mutableStateOf("0") }
        var culled by remember { mutableStateOf("0") }

        AlertDialog(
            onDismissRequest = { recordTargetBarn = null },
            title = { Text(if (isAr) "السجل اليومي لعنبر: ${barn.code}" else "Daily Record: ${barn.code}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(if (isAr) "نظام الحساب الآلي للعمر: $autoAge يوم منذ تسكين العنبر." else "Flock age auto-calculated: $autoAge days.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(
                        value = recordDate,
                        onValueChange = { recordDate = it },
                        label = { Text(if (isAr) "التاريخ (YYYY-MM-DD)" else "Date") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = feedMor,
                            onValueChange = { feedMor = it },
                            label = { Text(if (isAr) "علف صباحاً (كجم)" else "Morning Feed (Kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = feedEve,
                            onValueChange = { feedEve = it },
                            label = { Text(if (isAr) "علف مساءً (كجم)" else "Evening Feed (Kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = waterLiters,
                        onValueChange = { waterLiters = it },
                        label = { Text(if (isAr) "استهلاك المياه (لتر)" else "Water consumption (L)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = mortMor,
                            onValueChange = { mortMor = it },
                            label = { Text(if (isAr) "النافق صباحاً" else "Mortality AM") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = mortEve,
                            onValueChange = { mortEve = it },
                            label = { Text(if (isAr) "النافق مساءً" else "Mortality PM") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(if (isAr) "عمليات المنصرف والبيع والإنتاج:" else "Disposed / Sold / Processed chicks:", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = sold,
                            onValueChange = { sold = it },
                            label = { Text(if (isAr) "بيع" else "Sold") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = domestic,
                            onValueChange = { domestic = it },
                            label = { Text(if (isAr) "استهلاك" else "Domestic") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = culled,
                            onValueChange = { culled = it },
                            label = { Text(if (isAr) "إعدام" else "Culled") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val record = DailyRecord(
                            barnId = barn.id,
                            date = recordDate,
                            ageDays = autoAge,
                            feedMorningQty = feedMor.toDoubleOrNull() ?: 0.0,
                            feedEveningQty = feedEve.toDoubleOrNull() ?: 0.0,
                            waterQty = waterLiters.toDoubleOrNull() ?: 0.0,
                            mortalityMorning = mortMor.toIntOrNull() ?: 0,
                            mortalityEvening = mortEve.toIntOrNull() ?: 0,
                            soldQty = sold.toIntOrNull() ?: 0,
                            domesticQty = domestic.toIntOrNull() ?: 0,
                            culledQty = culled.toIntOrNull() ?: 0
                        )
                        viewModel.saveDailyRecord(record) { success ->
                            if (!success) {
                                scope.launch {
                                    snackbarHostState.showSnackbar("فشل التسجيل: الصلاحيات غير كافية للمستخدم الحالي!")
                                }
                            }
                        }
                        recordTargetBarn = null
                    }
                ) {
                    Text(if (isAr) "حفظ وحساب البيانات" else "Save & calculate")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordTargetBarn = null }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }

    // Add Weekly Weight Dialog
    if (weightTargetBarn != null) {
        val barn = weightTargetBarn!!
        val calculatedWeek = ((viewModel.getBarnAge(barn) - 1) / 7 + 1).coerceAtLeast(1)

        var recordDate by remember { mutableStateOf(viewModel.getCurrentDateString()) }
        var weekNo by remember { mutableStateOf(calculatedWeek.toString()) }
        var avgWeight by remember { mutableStateOf("195.0") }
        var uniformity by remember { mutableStateOf("88.0") }
        var stdDev by remember { mutableStateOf("15.0") }

        AlertDialog(
            onDismissRequest = { weightTargetBarn = null },
            title = { Text(if (isAr) "تسجيل أوزان العينة: ${barn.code}" else "Sample Weighing: ${barn.code}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isAr) "التحليل آلياً يستهدف مطابقة ومقارنة الأوزان بالمعايير العالمية." else "Weights will be auto-compared with Cobb-Ross growth targets.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(
                        value = recordDate,
                        onValueChange = { recordDate = it },
                        label = { Text(if (isAr) "التاريخ (YYYY-MM-DD)" else "Date") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = weekNo,
                        onValueChange = { weekNo = it },
                        label = { Text(if (isAr) "الأسبوع الدراسي/الإنتاجي" else "Week Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = avgWeight,
                        onValueChange = { avgWeight = it },
                        label = { Text(if (isAr) "متوسط الوزن المسجل للعينة (جرام)" else "Avg Bird Weight (grams)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = uniformity,
                            onValueChange = { uniformity = it },
                            label = { Text(if (isAr) "عامل التناسق (%)" else "Uniformity %") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = stdDev,
                            onValueChange = { stdDev = it },
                            label = { Text(if (isAr) "الانحراف المعياري (جرام)" else "Std Dev (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sample = WeightSample(
                            barnId = barn.id,
                            date = recordDate,
                            weekNumber = weekNo.toIntOrNull() ?: 1,
                            averageWeight = avgWeight.toDoubleOrNull() ?: 0.0,
                            uniformity = uniformity.toDoubleOrNull() ?: 100.0,
                            standardDeviation = stdDev.toDoubleOrNull() ?: 0.0
                        )
                        viewModel.saveWeightSample(sample) { success ->
                            if (!success) {
                                scope.launch {
                                    snackbarHostState.showSnackbar("فشل التسجيل: عذراً، لا تمتلك الصلاحيات الكافية!")
                                }
                            }
                        }
                        weightTargetBarn = null
                    }
                ) {
                    Text(if (isAr) "تحليل وحفظ الوزن" else "Analyze & save")
                }
            },
            dismissButton = {
                TextButton(onClick = { weightTargetBarn = null }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }

    // Add Expense Dialog
    if (expenseTargetBarn != null) {
        val barn = expenseTargetBarn!!
        var expenseDate by remember { mutableStateOf(viewModel.getCurrentDateString()) }
        var category by remember { mutableStateOf("العلف") }
        var amount by remember { mutableStateOf("1200.0") }
        var notes by remember { mutableStateOf("شراء ركائب وإضافات أعلاف وتدفئة بروتين") }

        val categoriesList = listOf("العلف", "العلاجات والأدوية", "النشارة", "كهرباء ومياه", "أجور العمال", "أخرى")

        AlertDialog(
            onDismissRequest = { expenseTargetBarn = null },
            title = { Text(if (isAr) "تقييد نفقة لعنبر: ${barn.code}" else "Log Expense: ${barn.code}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = expenseDate,
                        onValueChange = { expenseDate = it },
                        label = { Text(if (isAr) "التاريخ (YYYY-MM-DD)" else "Date") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text(if (isAr) "قيمة المبلغ المالي (ر.ي)" else "Amount ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (isAr) "ملاحظات وتفاصيل الدفع" else "Payment comments") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(if (isAr) "صنف البند أو النفقة:" else "Expense Category:", style = MaterialTheme.typography.labelMedium)
                    categoriesList.forEach { cat ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { category = cat }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = category == cat, onClick = { category = cat })
                            Text(cat, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val expense = Expense(
                            barnId = barn.id,
                            date = expenseDate,
                            category = category,
                            amount = amount.toDoubleOrNull() ?: 0.0,
                            notes = notes
                        )
                        viewModel.saveExpense(expense) { success ->
                            if (!success) {
                                scope.launch {
                                    snackbarHostState.showSnackbar("فشل العملية: الصلاحيات غير كافية للتعديل!")
                                }
                            }
                        }
                        expenseTargetBarn = null
                    }
                ) {
                    Text(if (isAr) "تقييد كنفقة أرشيفية" else "Archive cost")
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseTargetBarn = null }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }
}

@Composable
fun QuickGridItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
