package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = FarmGreenSecondary,
    secondary = FarmGoldAccent,
    tertiary = FarmOrange,
    background = FarmDarkBg,
    surface = FarmDarkSurface,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = FarmTextOnDark,
    onSurface = FarmTextOnDark
)

private val LightColorScheme = lightColorScheme(
    primary = FarmGreenPrimary,
    secondary = FarmGreenSecondary,
    tertiary = FarmGoldAccent,
    background = FarmLightBg,
    surface = FarmLightSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = FarmLightText,
    onSurface = FarmLightText,
    surfaceVariant = Color(0xFFF1F5F9), // Slate-100 for light card hover / sections
    onSurfaceVariant = Color(0xFF64748B), // Slate-500 neutral text
    outline = FarmLightBorder, // Slate-200 border color
    outlineVariant = Color(0xFFCBD5E1), // Slate-300
    errorContainer = Color(0xFFFEE2E2), // Red-100
    onErrorContainer = Color(0xFF991B1B) // Red-800
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
