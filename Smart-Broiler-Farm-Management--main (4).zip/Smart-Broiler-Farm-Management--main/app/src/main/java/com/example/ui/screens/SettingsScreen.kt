package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.PoultryViewModel

@Composable
fun SettingsScreen(
    viewModel: PoultryViewModel
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    val userRole by viewModel.currentUserRole.collectAsState()
    val syncStatus by viewModel.cloudSyncStatus.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = if (isAr) "إعدادات النظام والصلاحيات" else "System Settings & Permissions",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (isAr) "تخصيص الأدوار، تبديل المدخلات، والمزامنة الإلكترونية" else "Configure system roles and backups",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 1. Language Toggle Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isAr) "لغة المستخدم / Language" else "App Display Language",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ElevatedButton(
                        onClick = { viewModel.currentLanguage.value = "ar" },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = if (isAr) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "العربية RTL", color = if (isAr) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ElevatedButton(
                        onClick = { viewModel.currentLanguage.value = "en" },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = if (!isAr) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "English LTR", color = if (!isAr) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // 2. User Roles & Permission Selector Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isAr) "مستوى صلاحية المستخدم الحالي" else "User Account Capability Role",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                val roles = listOf("Admin", "Supervisor", "Worker")
                roles.forEach { role ->
                    val isSelected = userRole == role
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.currentUserRole.value = role }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = isSelected, onClick = { viewModel.currentUserRole.value = role })
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = when (role) {
                                    "Admin" -> if (isAr) "مدير المزرعة (Full Admin)" else "Owner / Admin"
                                    "Supervisor" -> if (isAr) "مهندس مشرف (Supervisor)" else "Vet Supervisor"
                                    else -> if (isAr) "عامل عنبر (Worker - Read Only)" else "Barn Labourer"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = when (role) {
                                    "Admin" -> if (isAr) "صلاحيات تامة: إدخال، تعديل، حذف، أرشفة، وأرباح" else "Full privileges: Add, edit, erase structural configurations"
                                    "Supervisor" -> if (isAr) "إدخال بيانات السجلات والتحصين الميداني والأوزان" else "Operations permissions: feed indexes input and weighing records"
                                    else -> if (isAr) "عرض الفهارس العلمية، اللوحات، والتقارير الاسترشادية فقط" else "View only privileges: read charts and guide tips only"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 3. Electronic Archiving and Cloud Sync
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isAr) "نظام الأرشفة وسحابة مزامنة البيانات" else "Sync & Electronic Archiving",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isAr) "البيانات تحفظ محلياً على قاعدة بيانات SQLite آمنة لتعمل دون إنترنت بشكل كامل ومكفول." else "Farms databases are logged in encrypted local SQLite for complete offline durability.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = "${if (isAr) "حالة التزامن الرقمي:" else "Status:"} $syncStatus",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.triggerLocalManualSync() },
                    modifier = Modifier.fillMaxWidth().testTag("sync_data_btn")
                ) {
                    Icon(Icons.Default.Sync, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isAr) "مزامنة احتياطية يدوية الآن" else "Trigger Manual Cloud Backup")
                }
            }
        }

        // 4. System Standards info and Developer block
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = if (isAr) "النظام الإداري للمزارع المغلقة" else "Enterprise Broilers Platform",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (isAr) "تصميم متكامل يلائم متطلبات أداء سلالات (كوب، روس، إنديان ريفر)." else "Engineered perfectly to match Cobb, Ross & Indian River biological milestones.",
                    style = MaterialTheme.typography.bodySmall
                )
                Divider(modifier = Modifier.padding(vertical = 6.dp))
                Text(
                    text = if (isAr) "تطوير وإشراف علمي: د.ضيف الله الحسني" else "Veterinary Supervision: Dr. Dhaifallah Al-Hasani",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isAr) "الدعم الفني المتواصل على مدار الساعة: 773826501" else "Technical Hotline support: 773826501",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}
