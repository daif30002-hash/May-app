package com.example.data.database

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PoultryDao {

    // Barns
    @Query("SELECT * FROM barns ORDER BY code ASC")
    fun getAllBarns(): Flow<List<Barn>>

    @Query("SELECT * FROM barns WHERE id = :id")
    suspend fun getBarnById(id: Long): Barn?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBarn(barn: Barn): Long

    @Update
    suspend fun updateBarn(barn: Barn)

    @Delete
    suspend fun deleteBarn(barn: Barn)

    // Daily Records
    @Query("SELECT * FROM daily_records WHERE barnId = :barnId ORDER BY date DESC, id DESC")
    fun getDailyRecordsForBarn(barnId: Long): Flow<List<DailyRecord>>

    @Query("SELECT * FROM daily_records ORDER BY date DESC, id DESC")
    fun getAllDailyRecords(): Flow<List<DailyRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyRecord(record: DailyRecord): Long

    @Delete
    suspend fun deleteDailyRecord(record: DailyRecord)

    // Stock Items
    @Query("SELECT * FROM stock_items")
    fun getStockItems(): Flow<List<StockItem>>

    @Query("SELECT * FROM stock_items WHERE name = :name")
    suspend fun getStockItemByName(name: String): StockItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockItem(item: StockItem)

    // Stock Transactions
    @Query("SELECT * FROM stock_transactions ORDER BY date DESC, id DESC")
    fun getStockTransactions(): Flow<List<StockTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockTransaction(transaction: StockTransaction): Long

    // Weekly Weights
    @Query("SELECT * FROM weight_samples WHERE barnId = :barnId ORDER BY weekNumber ASC")
    fun getWeightSamplesForBarn(barnId: Long): Flow<List<WeightSample>>

    @Query("SELECT * FROM weight_samples ORDER BY date DESC")
    fun getAllWeightSamples(): Flow<List<WeightSample>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightSample(sample: WeightSample): Long

    // Alerts
    @Query("SELECT * FROM alerts WHERE isRead = 0 ORDER BY date DESC")
    fun getUnreadAlerts(): Flow<List<Alert>>

    @Query("SELECT * FROM alerts ORDER BY date DESC")
    fun getAllAlerts(): Flow<List<Alert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: Alert): Long

    @Query("UPDATE alerts SET isRead = 1 WHERE id = :id")
    suspend fun markAlertAsRead(id: Long)

    @Query("UPDATE alerts SET isRead = 1")
    suspend fun markAllAlertsAsRead()

    // Expenses
    @Query("SELECT * FROM expenses WHERE barnId = :barnId ORDER BY date DESC")
    fun getExpensesForBarn(barnId: Long): Flow<List<Expense>>

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Delete
    suspend fun deleteExpense(expense: Expense)
}
