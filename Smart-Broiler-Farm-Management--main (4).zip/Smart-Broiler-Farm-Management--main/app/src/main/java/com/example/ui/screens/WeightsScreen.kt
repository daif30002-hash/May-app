package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.PoultryScience
import com.example.ui.viewmodel.PoultryViewModel

@Composable
fun WeightsScreen(
    viewModel: PoultryViewModel,
    barns: List<Barn>,
    weights: List<WeightSample>
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    var selectedBarnForAnalysis by remember { mutableStateOf<Barn?>(null) }
    
    // Auto-select first barn if not selected
    LaunchedEffect(barns) {
        if (selectedBarnForAnalysis == null && barns.isNotEmpty()) {
            selectedBarnForAnalysis = barns.first()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("weights_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = if (isAr) "الأوزان الحية والتحليل القياسي" else "Body Weights & Growth Curving",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (isAr) "مقارنة تطور الأوزان بسلالات Cobb و Ross و Indian River" else "Benchmarking weights vs international indicators",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (barns.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(48.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "يرجى أولاً إنشاء عنبر في صفحة العنابر لتسجيل أوزانه." else "Please configure at least one active barn.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            // Barn selector row
            Text(
                text = if (isAr) "اختر العنبر للمقارنة الحيوية والوزنية:" else "Select Barn for scientific analysis:",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                barns.forEach { barn ->
                    FilterChip(
                        selected = selectedBarnForAnalysis?.id == barn.id,
                        onClick = { selectedBarnForAnalysis = barn },
                        label = { Text(barn.code) }
                    )
                }
            }

            if (selectedBarnForAnalysis != null) {
                val barn = selectedBarnForAnalysis!!
                val barnWeights = weights.filter { it.barnId == barn.id }.sortedBy { it.weekNumber }
                val targetBreed = PoultryScience.breeds.find { it.name.lowercase() == barn.breedType.lowercase() } ?: PoultryScience.breeds.first()

                // Display comparison chart (Standard vs Actual weights)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isAr) "مقارنة الوزن القياسي (${barn.breedType}) مقابل الوزن المسجل" else "Body Weight Curve (${barn.breedType}) vs Recorded",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Render sophisticated analytical Canvas-drawn chart
                        GrowthComparisonChart(
                            standardWeights = targetBreed.targetWeights,
                            recordedWeights = barnWeights,
                            primaryColor = MaterialTheme.colorScheme.primary,
                            standardColor = Color.Gray.copy(alpha = 0.5f)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(10.dp).background(MaterialTheme.colorScheme.primary).clip(RoundedCornerShape(5.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isAr) "مسار المزرعة الحالي" else "Live Weights", style = MaterialTheme.typography.labelSmall)
                            Spacer(modifier = Modifier.width(16.dp))
                            Box(modifier = Modifier.size(10.dp).background(Color.Gray.copy(alpha = 0.5f)).clip(RoundedCornerShape(5.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = if (isAr) "المسار القياسي القيادي" else "Breed Standard Weight", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                // Detailed weekly table
                Text(
                    text = if (isAr) "مؤشرات التناسق وصحة النمو الأسبوعي:" else "Uniformity & growth statistics:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                if (barnWeights.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Scale, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isAr) "لم يتم تسجيل عينات أوزان للعنبر بعد." else "No weekly weights recorded yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAr) "انقر على زر 'وزن عينة' في شاشة العنابر للمهندسين لتسجيل أول عينة." else "Log your weights inside Barns section to feed calculations.",
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    barnWeights.forEachIndexed { idx, sample ->
                        val standardTarget = targetBreed.targetWeights.getOrNull(sample.weekNumber) ?: 0.0
                        val weightOffset = sample.averageWeight - standardTarget
                        val isOverStandard = weightOffset >= 0

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isAr) "عينة الأسبوع ${sample.weekNumber}" else "Week ${sample.weekNumber} Sample",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = sample.date,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                
                                Divider(modifier = Modifier.padding(vertical = 8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(if (isAr) "الوزن المسجل" else "Weight", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${sample.averageWeight} جم", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text(if (isAr) "المعياري العالمي" else "Standard Weight", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("$standardTarget جم", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(if (isAr) "الانحراف والنمو" else "Deviation", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = "${if (isOverStandard) "+" else ""}${String.format("%.1f", weightOffset)} جم",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isOverStandard) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (isAr) "التجانس التناسقي (Uniformity): " else "Uniformity: ",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "${sample.uniformity}%",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (sample.uniformity >= 85.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                        )
                                    }

                                    // Evaluation advice
                                    Text(
                                        text = when {
                                            sample.uniformity >= 90.0 -> if (isAr) "تجانس ممتد ممتاز" else "Perfect uniformity"
                                            sample.uniformity >= 80.0 -> if (isAr) "متوسط طبيعي مقنع" else "Good progress"
                                            else -> if (isAr) "توزيع غير متناسق (مريض أولية)" else "Poor uneven flock size"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (sample.uniformity >= 85) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GrowthComparisonChart(
    standardWeights: List<Double>,
    recordedWeights: List<WeightSample>,
    primaryColor: Color,
    standardColor: Color,
    heightDp: Int = 200
) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .padding(top = 16.dp, bottom = 16.dp, start = 8.dp, end = 8.dp)
    ) {
        val maxStandardWeight = standardWeights.maxOrNull() ?: 3000.0
        val maxRecordedWeight = recordedWeights.maxOfOrNull { it.averageWeight } ?: 0.0
        val maxVal = (maxStandardWeight.coerceAtLeast(maxRecordedWeight) * 1.1).coerceAtLeast(1.0)

        val paddingOffset = 15f
        val usableWidth = size.width - 2 * paddingOffset
        val usableHeight = size.height - 2 * paddingOffset

        // draw background grids
        val lines = 5
        for (i in 0..lines) {
            val y = paddingOffset + (i.toFloat() / lines) * usableHeight
            drawLine(
                color = Color.LightGray.copy(alpha = 0.2f),
                start = Offset(paddingOffset, y),
                end = Offset(size.width - paddingOffset, y),
                strokeWidth = 2f
            )
        }

        // Draw Standard breed Curve
        val standardPoints = standardWeights.mapIndexed { i, weight ->
            val fractionX = i.toFloat() / (standardWeights.size - 1)
            val fractionY = (weight / maxVal).toFloat()
            Offset(
                x = paddingOffset + fractionX * usableWidth,
                y = paddingOffset + (1f - fractionY) * usableHeight
            )
        }

        if (standardPoints.isNotEmpty()) {
            val path = Path().apply {
                moveTo(standardPoints.first().x, standardPoints.first().y)
                for (i in 1..standardPoints.lastIndex) {
                    lineTo(standardPoints[i].x, standardPoints[i].y)
                }
            }
            drawPath(
                path = path,
                color = standardColor,
                style = Stroke(width = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
            )

            // draw standard labels for weeks (0..6)
            standardPoints.forEachIndexed { i, pt ->
                drawCircle(color = standardColor, radius = 5f, center = pt)
            }
        }

        // Draw Recorded Weights Points
        if (recordedWeights.isNotEmpty()) {
            val recordedPoints = recordedWeights.mapIndexed { idx, sample ->
                // Ensure week mapping (Week 0, 1, 2, 3, 4, 5, 6 corresponds to indexes)
                val wIdx = sample.weekNumber.coerceIn(0, 6)
                val fractionX = wIdx.toFloat() / 6f
                val fractionY = (sample.averageWeight / maxVal).toFloat()
                Offset(
                    x = paddingOffset + fractionX * usableWidth,
                    y = paddingOffset + (1f - fractionY) * usableHeight
                )
            }

            // Connect recorded weights with a beautiful solid line
            val recordedPath = Path().apply {
                moveTo(recordedPoints.first().x, recordedPoints.first().y)
                for (i in 1..recordedPoints.lastIndex) {
                    lineTo(recordedPoints[i].x, recordedPoints[i].y)
                }
            }

            drawPath(
                path = recordedPath,
                color = primaryColor,
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )

            recordedPoints.forEach { pt ->
                drawCircle(color = Color.White, radius = 10f, center = pt)
                drawCircle(color = primaryColor, radius = 6f, center = pt)
            }
        }
    }
}
