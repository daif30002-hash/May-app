package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.PoultryRepository
import com.example.data.repository.PoultryScience
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PoultryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PoultryRepository
    init {
        val database = AppDatabase.getDatabase(application)
        repository = PoultryRepository(database.poultryDao())
        
        // Seed database immediately
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // Role & Permissions state
    val currentUserRole = MutableStateFlow("Admin") // "Admin", "Supervisor", "Worker"

    fun canInsertOrEdit(): Boolean {
        val role = currentUserRole.value
        return role == "Admin" || role == "Supervisor"
    }

    fun canDelete(): Boolean {
        return currentUserRole.value == "Admin"
    }

    // Flows
    val barns: StateFlow<List<Barn>> = repository.allBarns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDailyRecords: StateFlow<List<DailyRecord>> = repository.allDailyRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stockItems: StateFlow<List<StockItem>> = repository.stockItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stockTransactions: StateFlow<List<StockTransaction>> = repository.stockTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWeightSamples: StateFlow<List<WeightSample>> = repository.allWeightSamples
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<Alert>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadAlerts: StateFlow<List<Alert>> = repository.unreadAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Language state: "ar" or "en"
    val currentLanguage = MutableStateFlow("ar")

    // Sync status state
    val cloudSyncStatus = MutableStateFlow("متزامن محلياً (Offline Connected)") // "متزامن محلياً (Offline Connected)", "جاري المزامنة...", "تم تحديث البيانات بنجاح"

    // Search state
    val barnSearchQuery = MutableStateFlow("")

    // Active Barn Filter for records/weights/expenses
    val selectedBarnIdFilter = MutableStateFlow<Long?>(null)

    // DB manipulation methods with permission checks
    fun saveBarn(barn: Barn, onResult: (Boolean) -> Unit = {}) {
        if (!canInsertOrEdit()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            if (barn.id == 0L) {
                repository.insertBarn(barn)
                // Trigger informational Alert
                repository.insertAlert(
                    Alert(
                        barnId = null,
                        title = "إنشاء عنبر جديد",
                        message = "تم تسكين الدورة في عنبر جديد بالكود: ${barn.code} بسعة ${barn.startingChicks} كتكوت.",
                        date = getCurrentDateString(),
                        severity = "INFO"
                    )
                )
            } else {
                repository.updateBarn(barn)
            }
            onResult(true)
        }
    }

    fun deleteBarn(barn: Barn, onResult: (Boolean) -> Unit = {}) {
        if (!canDelete()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.deleteBarn(barn)
            onResult(true)
        }
    }

    fun saveDailyRecord(record: DailyRecord, onResult: (Boolean) -> Unit = {}) {
        if (!canInsertOrEdit()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.insertDailyRecord(record)
            onResult(true)
        }
    }

    fun deleteDailyRecord(record: DailyRecord, onResult: (Boolean) -> Unit = {}) {
        if (!canDelete()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.deleteDailyRecord(record)
            onResult(true)
        }
    }

    fun addStockAdjustment(itemName: String, type: String, quantity: Double, notes: String, onResult: (Boolean) -> Unit = {}) {
        if (!canInsertOrEdit()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.addStockTransaction(itemName, type, quantity, notes)
            onResult(true)
        }
    }

    fun saveWeightSample(sample: WeightSample, onResult: (Boolean) -> Unit = {}) {
        if (!canInsertOrEdit()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.insertWeightSample(sample)
            onResult(true)
        }
    }

    fun saveExpense(expense: Expense, onResult: (Boolean) -> Unit = {}) {
        if (!canInsertOrEdit()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.insertExpense(expense)
            onResult(true)
        }
    }

    fun deleteExpense(expense: Expense, onResult: (Boolean) -> Unit = {}) {
        if (!canDelete()) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            repository.deleteExpense(expense)
            onResult(true)
        }
    }

    fun markAlertAsRead(id: Long) {
        viewModelScope.launch {
            repository.markAlertAsRead(id)
        }
    }

    fun markAllAlertsAsRead() {
        viewModelScope.launch {
            repository.markAllAlertsAsRead()
        }
    }

    fun triggerLocalManualSync() {
        viewModelScope.launch {
            cloudSyncStatus.value = "جاري مزامنة السجلات ومستودع اللقاحات والأدوية مع خوادم السحابة..."
            kotlinx.coroutines.delay(2000)
            cloudSyncStatus.value = "تمت المزامنة بنجاح! السجلات مؤرشفة ومشفرة بالكامل."
            kotlinx.coroutines.delay(3000)
            cloudSyncStatus.value = "متزامن محلياً (Offline Connected)"
        }
    }

    // Helper functions
    fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    fun calculateDaysAge(startDateStr: String): Int {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val startDate = sdf.parse(startDateStr) ?: return 1
            val diffMs = Date().time - startDate.time
            val diffDays = (diffMs / (1000 * 60 * 60 * 24)).toInt()
            return if (diffDays <= 0) 1 else diffDays + 1
        } catch (e: Exception) {
            return 1
        }
    }

    // High level Analytical variables or getters
    fun getBarnAge(barn: Barn): Int {
        return calculateDaysAge(barn.startDate)
    }

    fun getBarnMortalityRate(barn: Barn, records: List<DailyRecord>): Double {
        val barnRecords = records.filter { it.barnId == barn.id }
        val totalDead = barnRecords.sumOf { it.mortalityMorning + it.mortalityEvening }
        if (barn.startingChicks <= 0) return 0.0
        return (totalDead.toDouble() / barn.startingChicks.toDouble()) * 100.0
    }

    fun getBarnLiveCount(barn: Barn, records: List<DailyRecord>): Int {
        val barnRecords = records.filter { it.barnId == barn.id }
        val totalDead = barnRecords.sumOf { it.mortalityMorning + it.mortalityEvening }
        val totalSold = barnRecords.sumOf { it.soldQty }
        val totalInternal = barnRecords.sumOf { it.domesticQty }
        val totalCulled = barnRecords.sumOf { it.culledQty }
        return (barn.startingChicks - totalDead - totalSold - totalInternal - totalCulled).coerceAtLeast(0)
    }

    fun getBarnCumulativeFeed(barnId: Long, records: List<DailyRecord>): Double {
        return records.filter { it.barnId == barnId }.sumOf { it.feedMorningQty + it.feedEveningQty }
    }

    // Advanced Metrics: FCR, ADG, PI, Cumulative Feed
    // FCR = Total Feed consumed / Total weight produced
    // Total body weight produced = current live count * current average weight + sold weight
    fun calculateBarnFCR(barn: Barn, records: List<DailyRecord>, weights: List<WeightSample>): Double {
        val barnRecords = records.filter { it.barnId == barn.id }
        val totalFeed = barnRecords.sumOf { it.feedMorningQty + it.feedEveningQty } // in Kg
        if (totalFeed <= 0.0) return 0.0

        val latestWeightSample = weights.filter { it.barnId == barn.id }.maxByOrNull { it.weekNumber }
        val currentWeightGrams = latestWeightSample?.averageWeight ?: 42.0 // start with 42g if none
        val currentLiveCount = getBarnLiveCount(barn, records)
        
        // Convert live weight to kg
        val liveWeightKg = (currentLiveCount * currentWeightGrams) / 1000.0
        
        // For accurate cumulative weight, let's also estimate sold weight if any (e.g. assume they sold weight at typical 2000g)
        val soldCount = barnRecords.sumOf { it.soldQty }
        val soldWeightKg = (soldCount * 2200.0) / 1000.0 // average sell weight ~ 2.2 kg

        val totalWeightProducedKg = liveWeightKg + soldWeightKg
        if (totalWeightProducedKg <= 0.0) return 0.0

        return totalFeed / totalWeightProducedKg
    }

    // ADG = (Average Weight - Initial Weight) / Age days
    fun calculateBarnADG(barn: Barn, weights: List<WeightSample>, ageDays: Int): Double {
        if (ageDays <= 0) return 0.0
        val latestWeightSample = weights.filter { it.barnId == barn.id }.maxByOrNull { it.weekNumber }
        val currentWeightGrams = latestWeightSample?.averageWeight ?: 42.0
        return (currentWeightGrams - 42.0) / ageDays // grams per day
    }

    // Production Index (EPEF / PI) = [Survival Rate % * Live Weight Kg] / [Age in Days * FCR] * 100
    fun calculateBarnProductionIndex(barn: Barn, records: List<DailyRecord>, weights: List<WeightSample>): Double {
        val ageDays = getBarnAge(barn)
        if (ageDays <= 0) return 0.0
        
        val fcr = calculateBarnFCR(barn, records, weights)
        if (fcr <= 0.0) return 0.0

        val liveCount = getBarnLiveCount(barn, records)
        val survivalRate = (liveCount.toDouble() / barn.startingChicks.toDouble()) * 100.0
        
        val latestWeight = weights.filter { it.barnId == barn.id }.maxByOrNull { it.weekNumber }?.averageWeight ?: 42.0
        val weightKg = latestWeight / 1000.0

        return (survivalRate * weightKg) / (ageDays * fcr) * 100.0
    }

    // Estimated Weight Forecast and needed feed at end of cycle (Day 42 is common targets)
    fun predictEndOfCycleMetrics(barn: Barn, records: List<DailyRecord>, weights: List<WeightSample>): Pair<Double, Double> {
        val standard = PoultryScience.breeds.find { it.name.lowercase() == barn.breedType.lowercase() } ?: PoultryScience.breeds.first()
        val targetWeightAtDay42 = standard.targetWeights.lastOrNull() ?: 3000.0 // in grams
        
        val liveCount = getBarnLiveCount(barn, records)
        // typical broiler eats ~4.5 - 5.0 kg feed cumulative over 42 days cycle.
        // We can estimate remainder of feed:
        val currentAge = getBarnAge(barn)
        val daysRemaining = (42 - currentAge).coerceAtLeast(0)
        
        val feedAlreadyConsumed = getBarnCumulativeFeed(barn.id, records)
        // standard total feed for entire flock = currentLiveCount * 4.8 Kg (avg flock standard lifetime consumption)
        val estimatedTotalFeedKg = liveCount * 4.8
        val neededFeedRemainderKg = (estimatedTotalFeedKg - feedAlreadyConsumed).coerceAtLeast(0.0)

        return Pair(targetWeightAtDay42, neededFeedRemainderKg)
    }

    // Stock Forecast in days: current stock / daily intake rate
    fun calculateStockForecastDays(itemName: String, stockItem: StockItem, records: List<DailyRecord>): Int {
        if (stockItem.currentBalance <= 0) return 0
        
        // Find daily feed consumption averages from the last 5 days
        val recentRecords = records.take(5)
        if (recentRecords.isEmpty()) return 30 // default estimate if no records
        
        val totalConsumedInRecent = recentRecords.sumOf { it.feedMorningQty + it.feedEveningQty }
        val avgDailyIntake = totalConsumedInRecent / recentRecords.size.toDouble()

        if (avgDailyIntake <= 0.0) return 40 // default high estimate if consumption not entered
        return (stockItem.currentBalance / avgDailyIntake).toInt().coerceIn(0, 99)
    }
}
