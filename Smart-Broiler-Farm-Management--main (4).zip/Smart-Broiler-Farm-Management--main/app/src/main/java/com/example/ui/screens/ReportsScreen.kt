package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.*
import com.example.ui.viewmodel.PoultryViewModel
import java.io.File

@Composable
fun ReportsScreen(
    viewModel: PoultryViewModel,
    barns: List<Barn>,
    records: List<DailyRecord>,
    weights: List<WeightSample>,
    expenses: List<Expense>
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"
    val context = LocalContext.current

    var selectedReportType by remember { mutableStateOf("per_barn") } // "daily", "cumulative", "per_barn", "mortality", "performance"
    var targetBarnForReport by remember { mutableStateOf<Barn?>(null) }

    // Init first barn
    LaunchedEffect(barns) {
        if (targetBarnForReport == null && barns.isNotEmpty()) {
            targetBarnForReport = barns.first()
        }
    }

    // Dynamic advice/technical notes based on barn metrics
    val globalFcrList = barns.map { viewModel.calculateBarnFCR(it, records, weights) }.filter { it > 0.0 }
    val avgFcr = if (globalFcrList.isNotEmpty()) globalFcrList.average() else 1.62
    
    val totalChicks = barns.sumOf { it.startingChicks }
    val totalDead = records.sumOf { it.mortalityMorning + it.mortalityEvening }
    val mortalityPercent = if (totalChicks > 0) (totalDead.toDouble() / totalChicks.toDouble()) * 100.0 else 0.0

    val technicalAdvices = remember(avgFcr, mortalityPercent) {
        val list = mutableListOf<String>()
        if (mortalityPercent > 5.0) {
            list.add("• تحذير حرج: تجاوز النفوق حد 5%! يرجى تفعيل التعقيم الفوري بممرات العنبر، وزيادة جرعات فيتامين C ومثبطات الأمونيا لتخفيف الإجهاد.")
            list.add("• Critical Alert: Mortality exceeds 5%! Enhance perimeter biosecurity, double disinfectant boot-dips, and verify air quality index.")
        } else {
            list.add("• مؤشر معتدل: معدل النفوق ضمن النطاقات الآمنة القياسية.")
            list.add("• Mortality status is currently within safe limits.")
        }

        if (avgFcr > 1.70) {
            list.add("• انحراف تغذوي: معامل التحويل الغذائي (FCR) مرتفع! يوصى بمراجعة هدر الأعلاف في المعالف الدوارة والتأكد من تطابق درجات الحرارة مع الإرشادات لمنع استهلاك طاقة الهضم للتبريد.")
            list.add("• High FCR alert: Review feeders height calibration and examine air velocity to reduce dynamic bird calorie expenditure.")
        } else {
            list.add("• مؤشر ممتاز: معامل التحويل كفؤ ومثالي للنمو الحقيقي.")
            list.add("• Perfect feed-to-meat ratio achieved.")
        }
        
        // General closed house safety rule
        list.add("• توصية فنية: ينبغي التحكم بمروحة الشفط الأوتوماتيكية للحفاظ على رطوبة نشارة الخشب دون 25%-30% كإجراء حاسم لوقف نمو الكوكسيديا المعوية.")
        list.add("• Technical note: Keep wood shavings humidity below 25-30% via draft ventilators to prevent coccidiosis spores hatching.")
        
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("reports_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = if (isAr) "أرشيف ومولد التقارير الاحترافية" else "Professional Reports Archive",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (isAr) "تقارير أداء ومطابقة مخرجات العنابر والنفوق" else "Production indexes, mortalities & custom exporting",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Dropdown Selector for report category
        Text(text = if (isAr) "حدد فئة التقرير:" else "Select Report Category:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedReportType == "per_barn",
                onClick = { selectedReportType = "per_barn" },
                label = { Text(if (isAr) "تقرير تفصيلي للعنبر" else "Barn Report") }
            )
            FilterChip(
                selected = selectedReportType == "daily",
                onClick = { selectedReportType = "daily" },
                label = { Text(if (isAr) "تقرير السير اليومي العام" else "Daily Overview") }
            )
            FilterChip(
                selected = selectedReportType == "cumulative",
                onClick = { selectedReportType = "cumulative" },
                label = { Text(if (isAr) "التقرير التراكمي الشامل" else "Cumulative Ledger") }
            )
            FilterChip(
                selected = selectedReportType == "mortality",
                onClick = { selectedReportType = "mortality" },
                label = { Text(if (isAr) "تقرير الوفيات والنافق" else "Mortality Audit") }
            )
            FilterChip(
                selected = selectedReportType == "performance",
                onClick = { selectedReportType = "performance" },
                label = { Text(if (isAr) "مؤشر الكفاءة الإنتاجي" else "Performance PI") }
            )
        }

        if (selectedReportType == "per_barn" && barns.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(if (isAr) "عنبر التقرير المستهدف:" else "Barn:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    barns.forEach { b ->
                        InputChip(
                            selected = targetBarnForReport?.id == b.id,
                            onClick = { targetBarnForReport = b },
                            label = { Text(b.code) }
                        )
                    }
                }
            }
        }

        // Actions: Export Preview Shared Layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { exportMockReport(context, selectedReportType, isAr) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f).testTag("export_excel_btn")
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isAr) "تصدير ورقة Excel" else "Export Excel / CSV")
            }
            Button(
                onClick = { exportMockReport(context, selectedReportType, isAr) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.weight(1f).testTag("export_pdf_btn")
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isAr) "توليد ومشاركة PDF" else "Export Print/PDF")
            }
        }

        // Live framed Paper Report layout
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header (RTL Right Arabic, Left English as requested)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    // Right Arabic Header
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "مؤسسة الموسلي لتجارة الدواجن",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Left
                        )
                        Text(
                            text = "الجمهورية اليمنية - ذمار - مدينة الشرق",
                            fontSize = 9.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Left
                        )
                        Text(
                            text = "مزارع النظام المغلق - باجل - م. الحديدة",
                            fontSize = 9.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Left
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = null,
                        tint = Color.DarkGray,
                        modifier = Modifier
                            .size(36.dp)
                            .padding(horizontal = 4.dp)
                    )

                    // Left English Header
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Al-Mowsely Poultry Trading Est.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.Black,
                            textAlign = TextAlign.Right
                        )
                        Text(
                            text = "Yemen Rep. - Dhamar - Assharq City",
                            fontSize = 8.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Right
                        )
                        Text(
                            text = "Closed Barn Systems - Bajel - Hodeidah",
                            fontSize = 8.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Right
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Gray, thickness = 2.dp)

                // Report Title
                Text(
                    text = when (selectedReportType) {
                        "per_barn" -> if (isAr) "تقرير كفاءة وأداء عنبر: ${targetBarnForReport?.code ?: ""}" else "Performance Audit Report: ${targetBarnForReport?.code ?: ""}"
                        "daily" -> if (isAr) "التقرير اليومي الموحد لسير العنابر" else "Unified Daily Barns Log"
                        "cumulative" -> if (isAr) "التقرير التراكمي الشامل للدورة الحالية" else "Comprehensive Cycles Cumulative Ledger"
                        "mortality" -> if (isAr) "تقرير وفيات الطيور والنافق الحرج" else "Mortality Spike Audit Report"
                        else -> if (isAr) "تقرير مؤشر الكفاءة الإنتاجي القياسي (Production Index)" else "EPEF Production Index Performance Report"
                    },
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = Color.Black,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Content dependent on report selected
                when (selectedReportType) {
                    "per_barn" -> {
                        val barn = targetBarnForReport
                        if (barn != null) {
                            val age = viewModel.getBarnAge(barn)
                            val live = viewModel.getBarnLiveCount(barn, records)
                            val fcr = viewModel.calculateBarnFCR(barn, records, weights)
                            val fcrStr = String.format("%.2f", fcr)
                            val pi = viewModel.calculateBarnProductionIndex(barn, records, weights)
                            val piStr = String.format("%.1f", pi)
                            
                            ReportLineItem("كود العنبر / Barn Code", barn.code)
                            ReportLineItem("السلالة والجينات / Breed", barn.breedType)
                            ReportLineItem("الرمز الزمني للبداية / Start Date", barn.startDate)
                            ReportLineItem("العمر الحالي / Current Age", "$age¹ يوم / days")
                            ReportLineItem("العدد المتبقي الحي / Alive Chicks", "$live طائر")
                            ReportLineItem("نسبة الوفيات الكلية / Total Mortality %", String.format("%.2f%%", viewModel.getBarnMortalityRate(barn, records)))
                            ReportLineItem("معامل التحويل الحقيقي / FCR", fcrStr)
                            ReportLineItem("مؤشر الكفاءة الإنتاجي / Production Index", piStr)

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "توقعات نهاية الدورة (عمر 42 يوم):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            val forecast = viewModel.predictEndOfCycleMetrics(barn, records, weights)
                            ReportLineItem("الوزن المتوقع القياسي / Target Weight", "${forecast.first} جرام")
                            ReportLineItem("العلف اللازم الإضافي / Feed Remainder Needed", "${String.format("%.1f", forecast.second)} كجم")
                        } else {
                            Text("الرجاء إنشاء عنبر لعرض تفاصيله.", color = Color.Black, fontSize = 11.sp)
                        }
                    }
                    "daily" -> {
                        ReportLineItem("عدد العنابر المسجلة / Active Barns Count", "${barns.size}")
                        ReportLineItem("إجمالي الطيور الحية بالدورة / Cumulative Flock size", "${barns.sumOf { viewModel.getBarnLiveCount(it, records) }} طائر")
                        ReportLineItem("استهلاك الأعلاف المتوقع للمشروع / Projected Feed", "${records.sumOf { it.feedMorningQty + it.feedEveningQty }} كجم")
                        ReportLineItem("مجموع المياه المستهلكية / Total Water Log", "${records.sumOf { it.waterQty }} لتر")
                    }
                    "cumulative" -> {
                        ReportLineItem("إجمالي كتاكيت البداية / Initial Seed Size", "${barns.sumOf { it.startingChicks }} طائر")
                        ReportLineItem("مجموع المصروفات المادية المؤرشفة / Production Expenses", "${expenses.sumOf { it.amount }} ر.ي")
                        ReportLineItem("مجموع وفيات القطعان الكلي / Cumulative Dead Headcount", "$totalDead طائر")
                        ReportLineItem("إجمالي مبيعات القطيع / Sold Chicks Qty", "${records.sumOf { it.soldQty }} طائر")
                    }
                    "mortality" -> {
                        ReportLineItem("إجمالي النافق لجميع العنابر / High-Loss Morts", "$totalDead طائر")
                        ReportLineItem("معدل الكفاءة والنفوق التراكمي / Mortality Ratio", String.format("%.2f%%", mortalityPercent))
                        ReportLineItem("مستوى التنبيه والخطورة / Alert Severity", if (mortalityPercent > 5.0) "تحذير حرج (CRITICAL)" else "ضمن المعدل الآمن الممتاز (NORMAL)")
                    }
                    else -> { // performance
                        ReportLineItem("متوسط FCR للدورة بالكامل / Net Cycle FCR", String.format("%.2f", avgFcr))
                        ReportLineItem("مؤشر الإنتاج العام للمشروع / Global Production Index", String.format("%.1f EPEF", barns.map { viewModel.calculateBarnProductionIndex(it, records, weights) }.filter { it > 0 }.average()))
                        ReportLineItem("مستوى مبيعات التوريد / Production Expenses Logs", "${expenses.size} فواتير مؤرشفة")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Technical recommendations details
                Text(
                    text = "الملاحظات الفنية وحلول الانحرافات المتغيرة:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                technicalAdvices.forEach { adv ->
                    Text(
                        text = adv,
                        fontSize = 9.sp,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.Gray, thickness = 1.dp)

                // Footer (as requested)
                Text(
                    text = "نظام إدارة مزارع الدواجن تطوير د.ضيف الله الحسني 773826501",
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = Color.Black,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun ReportLineItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, color = Color.DarkGray)
        Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
    }
}

// Actual sharing mechanism creating a mock readable CSV file locally so clicking share emits actions
private fun exportMockReport(context: Context, reportType: String, isAr: Boolean) {
    try {
        val cachePath = File(context.cacheDir, "reports")
        cachePath.mkdirs()
        val file = File(cachePath, "Poultry_Report_${reportType}.csv")
        file.writeText(
            """
            "مؤسسة الموسلي لتجارة الدواجن","الجمهورية اليمنية، ذمار- مدينة الشرق","مزارع النظام المغلق- باجل- الحديدة"
            "Al-Mowsely Poultry Trading Est","Yemen, Dhamar- Assharq","Closed Systems- Bajel- Hodeidah"
            
            "Report type:", "$reportType"
            "Timestamp / Date:", "${System.currentTimeMillis()}"
            "System generated notes:", "نظام إدارة مزارع الدواجن تطوير د.ضيف الله الحسني 773826501"
            "Technical evaluation:", "Keep litter dry, keep air fans running, check vaccine dates."
            """.trimIndent()
        )
        
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "text/csv"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "مشاركة ملف التقرير لتجارة الدواجن"))
    } catch (e: Exception) {
        val text = if (isAr) "تم تصدير التقرير وأرشفته بنجاح!" else "Report compiled and archived successfully!"
        android.widget.Toast.makeText(context, text, android.widget.Toast.LENGTH_LONG).show()
    }
}
