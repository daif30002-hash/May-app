package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "barns")
data class Barn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val capacity: Int,
    val startingChicks: Int,
    val startDate: String, // YYYY-MM-DD
    val breedType: String  // Cobb 500, Ross 308, Indian River
)

@Entity(tableName = "daily_records")
data class DailyRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barnId: Long,
    val date: String, // YYYY-MM-DD
    val ageDays: Int,
    val feedMorningQty: Double, // in Kg
    val feedEveningQty: Double, // in Kg
    val waterQty: Double,       // in Liters
    val mortalityMorning: Int,
    val mortalityEvening: Int,
    val soldQty: Int,
    val domesticQty: Int,
    val culledQty: Int
)

@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey val name: String, // "Feed Starter", "Feed Grower", "Feed Finisher", "Wood Shavings", "Medicines", "Vitamins"
    val currentBalance: Double,
    val unit: String,             // "Kg", "Bags", "Liters", "Bottles"
    val minLimit: Double
)

@Entity(tableName = "stock_transactions")
data class StockTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemName: String,
    val type: String, // "IN" / "OUT"
    val quantity: Double,
    val date: String,
    val notes: String
)

@Entity(tableName = "weight_samples")
data class WeightSample(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barnId: Long,
    val date: String,
    val weekNumber: Int,
    val averageWeight: Double,      // in grams
    val uniformity: Double,        // % uniformity
    val standardDeviation: Double  // in grams
)

@Entity(tableName = "alerts")
data class Alert(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barnId: Long?,
    val title: String,
    val message: String,
    val date: String,
    val isRead: Boolean = false,
    val severity: String = "INFO" // "INFO", "WARNING", "CRITICAL"
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barnId: Long,
    val date: String,
    val category: String, // "Feed", "Medicines", "Wood Shavings", "Fuel/Electricity", "Wages", "Misc"
    val amount: Double,
    val notes: String
)
