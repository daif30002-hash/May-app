package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PoultryViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: PoultryViewModel = viewModel()
                
                // Collect states
                val barns by viewModel.barns.collectAsState()
                val records by viewModel.allDailyRecords.collectAsState()
                val stock by viewModel.stockItems.collectAsState()
                val weights by viewModel.allWeightSamples.collectAsState()
                val unreadAlerts by viewModel.unreadAlerts.collectAsState()
                val expenses by viewModel.allExpenses.collectAsState()
                val language by viewModel.currentLanguage.collectAsState()
                val isAr = language == "ar"

                var currentRoute by remember { mutableStateOf("dashboard") }

                Scaffold(
                    modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("app_navigation_bar")
                        ) {
                            NavigationBarItem(
                                selected = currentRoute == "dashboard",
                                onClick = { currentRoute = "dashboard" },
                                icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                                label = { Text(if (isAr) "الرئيسة" else "Dashboard", maxLines = 1) },
                                modifier = Modifier.testTag("nav_dashboard")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "barns",
                                onClick = { currentRoute = "barns" },
                                icon = { Icon(Icons.Default.Warehouse, contentDescription = null) },
                                label = { Text(if (isAr) "العنابر" else "Barns", maxLines = 1) },
                                modifier = Modifier.testTag("nav_barns")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "stock",
                                onClick = { currentRoute = "stock" },
                                icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                                label = { Text(if (isAr) "المخازن" else "Stock", maxLines = 1) },
                                modifier = Modifier.testTag("nav_stock")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "weights",
                                onClick = { currentRoute = "weights" },
                                icon = { Icon(Icons.Default.LineAxis, contentDescription = null) },
                                label = { Text(if (isAr) "الأوزان" else "Weighings", maxLines = 1) },
                                modifier = Modifier.testTag("nav_weights")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "reports",
                                onClick = { currentRoute = "reports" },
                                icon = { Icon(Icons.Default.Assessment, contentDescription = null) },
                                label = { Text(if (isAr) "التقارير" else "Reports", maxLines = 1) },
                                modifier = Modifier.testTag("nav_reports")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "guide",
                                onClick = { currentRoute = "guide" },
                                icon = { Icon(Icons.Default.HealthAndSafety, contentDescription = null) },
                                label = { Text(if (isAr) "الصحة" else "Guide", maxLines = 1) },
                                modifier = Modifier.testTag("nav_guide")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "settings",
                                onClick = { currentRoute = "settings" },
                                icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                label = { Text(if (isAr) "الإعدادات" else "Settings", maxLines = 1) },
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentRoute) {
                            "dashboard" -> DashboardScreen(
                                viewModel = viewModel,
                                barns = barns,
                                records = records,
                                stock = stock,
                                weights = weights,
                                alerts = unreadAlerts,
                                onNavigateToSection = { route -> currentRoute = route }
                            )
                            "barns" -> BarnsScreen(
                                viewModel = viewModel,
                                barns = barns,
                                records = records,
                                weights = weights,
                                expenses = expenses
                            )
                            "stock" -> StockScreen(
                                viewModel = viewModel,
                                stockItems = stock,
                                transactions = viewModel.stockTransactions.collectAsState().value,
                                records = records,
                                expenses = expenses
                            )
                            "weights" -> WeightsScreen(
                                viewModel = viewModel,
                                barns = barns,
                                weights = weights
                            )
                            "reports" -> ReportsScreen(
                                viewModel = viewModel,
                                barns = barns,
                                records = records,
                                weights = weights,
                                expenses = expenses
                            )
                            "guide" -> GuideScreen(
                                viewModel = viewModel
                            )
                            "settings" -> SettingsScreen(
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}
