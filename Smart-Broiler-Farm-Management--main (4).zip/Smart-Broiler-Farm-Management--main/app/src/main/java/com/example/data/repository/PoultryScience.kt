package com.example.data.repository

data class BreedStandard(
    val name: String,
    val targetWeights: List<Double> // Index 0 to 6 representing Week 0 to 6 in grams
)

data class DiseaseInfo(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val ageRange: String,
    val symptomsAr: String,
    val symptomsEn: String,
    val treatmentAr: String,
    val treatmentEn: String,
    val antibioticAr: String,
    val antibioticEn: String,
    val dosageAr: String,
    val dosageEn: String,
    val preventionAr: String,
    val preventionEn: String
)

data class VaccineScheduleItem(
    val day: Int,
    val nameAr: String,
    val nameEn: String,
    val methodAr: String,
    val methodEn: String,
    val notesAr: String,
    val notesEn: String
)

object PoultryScience {

    val breeds = listOf(
        BreedStandard(
            name = "Ross 308",
            targetWeights = listOf(42.0, 195.0, 480.0, 940.0, 1560.0, 2280.0, 3000.0)
        ),
        BreedStandard(
            name = "Cobb 500",
            targetWeights = listOf(40.0, 190.0, 470.0, 925.0, 1540.0, 2250.0, 2950.0)
        ),
        BreedStandard(
            name = "Indian River",
            targetWeights = listOf(41.0, 185.0, 460.0, 900.0, 1500.0, 2200.0, 2900.0)
        )
    )

    val vaccines = listOf(
        VaccineScheduleItem(1, "تحصين هتشني وعمر برونشيت", "Hatchery ND + IB", "رش أو حقن في الفقاسة", "Spray or Injection at hatchery", "للوقاية المبكرة من النيوكاسل والالتهاب الشعبي", "Early protection from ND + IB"),
        VaccineScheduleItem(7, "تحصين نيوكاسل + برونشيت (H120)", "ND + IB (Clone 30 / Ma5)", "تقطير في العين أو ماء الشرب", "Eye drop or Drinking water", "التحصين الأولي ضد النيوكاسل والالتهاب الشعبي", "Primary ND + IB vaccination"),
        VaccineScheduleItem(12, "تحصين جمبورو متوسط شدة", "IBD / Gumboro (Intermediate)", "ماء الشرب بعد تعطيش ساعتين", "Drinking water - 2h fasting", "الجرعة الأولى للوقاية من مرض الجمبورو الخطير", "First dose for Gumboro prevention"),
        VaccineScheduleItem(18, "تحصين نيوكاسل متطور (لاسوتا)", "ND (LaSota / Clone)", "ماء الشرب أو تقطير", "Drinking water or Eye drop", "تنشيط المناعة ضد فيروس النيوكاسل الهضمي والتنفسي", "Booster ND protection"),
        VaccineScheduleItem(24, "تحصين جمبورو جرعة ثانية", "IBD / Gumboro Booster", "ماء الشرب", "Drinking water", "لضمان التغطية المناعية للطيور المتأخرة", "To ensure complete flock protection")
    )

    val diseases = listOf(
        DiseaseInfo(
            id = "nd",
            nameAr = "مرض النيوكاسل (ND)",
            nameEn = "Newcastle Disease",
            ageRange = "10 - 45 يوم",
            symptomsAr = "خمول شديد، كحة وعطس، إسهال مائي مخضر، التواء الرقبة (أعراض عصبية)، نفوق مفاجئ سريع الارتفاع.",
            symptomsEn = "Severe depression, coughing, gasping, green watery droppings, twisted neck (nervous signs), sudden high mortality.",
            treatmentAr = "مرض فيروسي لا علاج له بالضادات، ولكن يتم إعطاء مضاد بكتيري لمنع العدوى المشتركة + منشطات مناعة وفيتامين C.",
            treatmentEn = "Viral disease: No specific treatment. Control secondary bacterial infections with broad-spectrum antibacterials, immunostimulants, and Vit C.",
            antibioticAr = "مزيج كولستين + تايلوزين (Colistin + Tylosin)",
            antibioticEn = "Colistin + Tylosin combination",
            dosageAr = "1 جرام لكل لتر ماء شرب لمدة 3 - 5 أيام متواصلة.",
            dosageEn = "1g per 1 Liter of drinking water for 3 - 5 consecutive days.",
            preventionAr = "الالتزام التام بجدول التحصينات (يوم 7 و 18)، رش ممرات العنبر باليود المعقم، منع دخول زوار غرباء ومكافحة القوارض والطيور البرية.",
            preventionEn = "Adhere strictly to vaccination schedule (days 7 & 18). Disinfect pathways with Iodine regularly. Restrict farm visitors. Vector control."
        ),
        DiseaseInfo(
            id = "ib",
            nameAr = "الالتهاب الشعبي المعدي (IB)",
            nameEn = "Infectious Bronchitis",
            ageRange = "1 - 30 يوم",
            symptomsAr = "صوت حشرة تنفسية (خرخرة)، عطس وسعال، انتفاخ الجيوب الأنفية، رطوبة العينين، زيادة استهلاك الفحم أو الماء.",
            symptomsEn = "Respiratory rales, sneezing, wet eyes, swollen sinuses, wet litter, depressed feed conversion.",
            treatmentAr = "مرض فيروسي تنفسي. يوصى برفع حرارة العنبر 1-2 درجات، إعطاء موسعات شعب تنفسية ومضاد حيوي تنفسي للعدوى المشتركة.",
            treatmentEn = "Viral respiratory disease. Raise barn temperature by 1-2 degrees. Provide bronchial dilators, mucolytics, and respiratory antibiotics.",
            antibioticAr = "دوكسيسيكلين + إريثروميسين (Doxycycline + Erythromycin)",
            antibioticEn = "Doxycycline + Erythromycin",
            dosageAr = "1 جرام من الدوكسيسيكلين لكل 2 لتر ماء شرب لمدة 4 أيام.",
            dosageEn = "1g of Doxycycline per 2 Liters of drinking water for 4 days.",
            preventionAr = "تحصين الطيور في عمر 1 يوم وعمر 12 يوم، تهوية جيدة غير مباشرة لتجنب تيار الهواء البارد، والتطهير قبل التسكين.",
            preventionEn = "Vaccinate on day 1 (hatchery) and day 12. Maintain warm drafts-free active ventilation."
        ),
        DiseaseInfo(
            id = "ibd",
            nameAr = "مرض الجمبورو (Gumboro - IBD)",
            nameEn = "Infectious Bursal Disease",
            ageRange = "12 - 30 يوم",
            symptomsAr = "إسهال أبيض مائي لزج، طيور متجمعة وراقدة، انتفاش الريش، نقر المخرج، نفوق يقفز فجأة ثم يتراجع بعد 5 أيام.",
            symptomsEn = "Watery white diarrhea, severe depression, ruffled feathers, vent picking, mortality spike that peaks and recedes.",
            treatmentAr = "مرض فيروسي خطير يدمر غدة الجمبورو (المناعة). يمنع استخدام المضادات الحيوية العشوائية المجهدة للكلية. يوصى بمدرات البول، غسيل كلوى، وفيتامين K3.",
            treatmentEn = "Severe immunosuppressive viral disease. Avoid harsh antibiotics which stress kidneys. Provide kidney flushes, electrolytes, and Vit K3 + C.",
            antibioticAr = "أموكسيسيلين (Amoxicillin) - للوقاية من الكلوستريديا الثانوية",
            antibioticEn = "Amoxicillin - solely to prevent secondary clostridia",
            dosageAr = "أموكسيسيلين 1 جرام لكل لتر ونصف ماء لمدة 3 أيام بعد غسيل الكلى.",
            dosageEn = "1g of Amoxicillin per 1.5 Liters of water for 3 days after kidney flush.",
            preventionAr = "التحصين الدقيق باللقاح المعتدل شدة في عمر 12 إلى 14 يوم ومكرر في عمر 21 يوم، حرق جثث النافق فوراً.",
            preventionEn = "Adhere to Gumboro vaccines on day 12-14 and 21. Burn or deeply bury mortality promptly."
        ),
        DiseaseInfo(
            id = "crd",
            nameAr = "المرض التنفسي المزمن (CRD)",
            nameEn = "Chronic Respiratory Disease",
            ageRange = "15 - 45 يوم",
            symptomsAr = "عطاس شديد، رغوة في زوايا العين، صوت خرخرة في الليل، انخفاض استهلاك العلف بشكل حاد وتأخر الأوزان.",
            symptomsEn = "Persistent sneezing, foamy eye discharge, snoring sounds at night, sharp intake reduction, low body weights.",
            treatmentAr = "بكتيريا المايكوبلازما. حساسة جداً للمضادات المتخصصة بالجهاز التنفسي والمقشعات البرومية للشعب الهوائية.",
            treatmentEn = "Mycoplasma gallisepticum. Responsive to targeted respiratory macrolides combined with bronchial expectorants (Bromhexine).",
            antibioticAr = "تيلميكوسين أو تايلوزين تارترات (Tilmicosin / Tylosin)",
            antibioticEn = "Tilmicosin or Tylosin Tartrate",
            dosageAr = "تيلميكوسين 0.3 مل لكل لتر ماء شرب لمدة 3 أيام متتالية.",
            dosageEn = "Tilmicosin 0.3ml per 1 Liter of water for 3 consecutive days.",
            preventionAr = "شراء كتكوت منتج من أمهات خالية من المايكوبلازما، منع ارتفاع غاز الأمونيا في العنبر والمحافظة على رطوبة النشارة وتوفير مصادر تدفئة غير ملوثة.",
            preventionEn = "Purchase chicks from clean MG-free parents, maintain ammonia below 10-15 ppm, control dust."
        ),
        DiseaseInfo(
            id = "cocci",
            nameAr = "الكوكسيديا (Coccidiosis)",
            nameEn = "Coccidiosis",
            ageRange = "14 - 35 يوم",
            symptomsAr = "إسهال مدمم أو برتقالي هلامي، ضعف عام، بهوت لون الساق والمنقار، ميل الطيور للنوم الطويل وتدلي الأجنحة.",
            symptomsEn = "Bloody or orange mucoid diarrhea, paleness, drooping wings, extreme lethargy, flock unevenness.",
            treatmentAr = "طفيل الكوكسيديا المعوي. يستلزم التدخل السريع بمضادات الكوكسيديا وعلاج كلوستيريديا المتزامنة معها.",
            treatmentEn = "Protozoan intestinal parasite. Requires prompt administration of anticoccidials mixed with supportive kidney flushes and Vit K3.",
            antibioticAr = "أمبروليوم أو تولترازوريل (Amprolium / Toltrazuril)",
            antibioticEn = "Amprolium or Toltrazuril",
            dosageAr = "أمبروليوم 1.2 جرام لكل لتر ماء شرب لـ 4 أيام، أو تولترازوريل 1 مل/لتر لـ 2 يوم.",
            dosageEn = "Amprolium 1.2g per 1 Liter of water for 4 days, or Toltrazuril 1ml/L for 2 days.",
            preventionAr = "منع رطوبة النشارة مطلقاً، تهوية جيدة، استخدام مضاد كوكسيديا وقائي في خلطة العلف، رش مضاد للكوكسيديا على الفرشة.",
            preventionEn = "Keep litter dry (moisture < 25%). Use chemical/ionophore anticoccidials rotationally in feed."
        ),
        DiseaseInfo(
            id = "clost",
            nameAr = "الكلوستريديا / التهاب الأمعاء (Necrotic Enteritis)",
            nameEn = "Clostridia",
            ageRange = "15 - 35 يوم",
            symptomsAr = "انتفاخ الطائر، خروج براز غامق يشبه الشوكولاته ذو رائحة كريهة، نفوق مفاجئ دون أعراض تنفسية.",
            symptomsEn = "Dark, chocolate-colored malodorous feces, severe dehydration, rapid post-mortem decomposition, dark intestines.",
            treatmentAr = "بكتيريا لاهوائية تتغذى على تدمير جدار الأمعاء. تعالج بمضادات حيوية متخصصة مع مطهرات معوية ومنشطات كبد.",
            treatmentEn = "Anaerobic bacteria thriving on mucosal damage. Treat with targeted gut antimicrobials and hepatic protectants.",
            antibioticAr = "أموكسيسيلين أو لينكومايسين (Amoxicillin / Lincomycin)",
            antibioticEn = "Amoxicillin or Lincomycin",
            dosageAr = "أموكسيسيلين 1 جرام لكل لتر ونصف ماء لمدة 4 أيام في المساء.",
            dosageEn = "Amoxicillin 1g per 1.5 Liters of water for 4 days.",
            preventionAr = "الوقاية الصارمة من الكوكسيديا (حيث تفتح جرحاً تدخل منه الكلوستريديا)، ضبط جودة العلف ومنع تعفنه بمضاد السموم الفطرية.",
            preventionEn = "Prevent subclinical coccidiosis, use organic acids in water to keep low gut pH, rotate toxin-binders."
        ),
        DiseaseInfo(
            id = "ecoli",
            nameAr = "الكوليباسيلوز / الإيكولاي (E. coli)",
            nameEn = "Colibacillosis / E. coli",
            ageRange = "1 - 45 يوم",
            symptomsAr = "نفوق مرتفع في الأسبوع الأول، كسل الطيور، صعوبة الحركة، ظهور غشاء ليفي رمادي على الكبد والقلب عند التشريح.",
            symptomsEn = "Early chick mortality, depression, respiratory distress, cloudy air sacs, grey fibrinous pericarditis on autopsy.",
            treatmentAr = "بكتيريا سالبة الجرام تصيب الدم والأعضاء. تعالج بمضاد بكتيري واسع الطيف مع اشتراط عمل اختبار حساسية.",
            treatmentEn = "Systemic colibacillosis. Broad-spectrum gram-negative antimicrobials, preferably verified via sensitivity disc tests.",
            antibioticAr = "فوسفوميسين أو إنروفلوكساسين أو كولستين (Fosfomycin / Enrofloxacin / Colistin)",
            antibioticEn = "Fosfomycin, Enrofloxacin, or Colistin",
            dosageAr = "فوسفوميسين 1 جرام لكل لتر ماء لمدة 3 - 5 أيام.",
            dosageEn = "Fosfomycin 1g per 1 Liter of water for 3 - 5 days.",
            preventionAr = "تطهير وتعقيم مياه الشرب بالكلور أو معقمات المياه بشكل مستمر، تهوية جيدة، وتطهير غرف تحضين الكتاكيت.",
            preventionEn = "Ensure completely sanitized/chlorinated water supply (2-3 ppm free Cl). Hatchery and brooding house hygiene."
        )
    )

    val biosecurityAr = listOf(
        "غسيل وتطهير عنبر التسمين بالكامل بالمنظفات ثم الفيركون-أس قبل دخول الطيور.",
        "وضع مغطس أحذية معقم عند بوابة العنابر وتغيير محلول التعقيم يومياً.",
        "منع دخول أي شخص غريب أو تاجر مالم يمر عبر كابينة تطهير متطورة.",
        "إبقاء رطوبة نشارة الخشب معتدلة (لا تتجاوز 25%-30%) لتجنب تخمر الكوكسيديا والكلوستريديا.",
        "فحص وصيانة كفاءة مراوح الشفط وخلايا التبريد يومياً لتوفير تجديد كاف ومستمر للهواء النقي وسحب غاز الأمونيا السام.",
        "تعقيم وغسيل خزانات وخطوط مياه النبل للتخلص من البيوفيلم الجرثومي مرتين في الدورة.",
        "التخلص الفوري من الطيور الميتة بالحرق أو الدفن العميق بعيداً جداً عن العنابر."
    )

    val biosecurityEn = listOf(
        "Complete wash and sanitization of the barn using detergents followed by Virkon-S before flock arrival.",
        "Deploy active boot-dips containing heavy-duty disinfectants at doors; change daily.",
        "Strictly ban casual visitors or chicken traders from accessing the active growth zones.",
        "Keep wood shavings dry (moisture below 25-30%) to avert coccidiosis and necrotic enteritis propagation.",
        "Test exhaustive fans and cooling pads daily to secure uninterrupted oxygenation and ammonia sweep.",
        "Sanitize pipelines and drinking nipple lines with organic flushing fluids mid-cycle.",
        "Incinerate or bury flock mortalities instantly away from barns to check biological transfer."
    )
}
