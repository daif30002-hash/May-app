package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.viewmodel.PoultryViewModel

@Composable
fun DashboardScreen(
    viewModel: PoultryViewModel,
    barns: List<Barn>,
    records: List<DailyRecord>,
    stock: List<StockItem>,
    weights: List<WeightSample>,
    alerts: List<Alert>,
    onNavigateToSection: (String) -> Unit
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    // Real-time IoT Simulation States
    val activeSimulationBarn = remember(barns) { barns.firstOrNull() }
    var selectedBarnIdSim by remember { mutableStateOf(activeSimulationBarn?.id ?: 0L) }
    if (selectedBarnIdSim == 0L && barns.isNotEmpty()) {
        selectedBarnIdSim = barns.first().id
    }
    
    var barnSimTemps by remember { mutableStateOf(mapOf<Long, Float>()) }
    var barnSimHumidities by remember { mutableStateOf(mapOf<Long, Float>()) }
    var autoRegulateIoT by remember { mutableStateOf(true) }

    var manualFanOn by remember { mutableStateOf(false) }
    var manualHeaterOn by remember { mutableStateOf(false) }
    var manualCoolingOn by remember { mutableStateOf(false) }
    var manualFeederOn by remember { mutableStateOf(true) }

    val selectedBarn = barns.find { it.id == selectedBarnIdSim }
    val selectedAge = selectedBarn?.let { viewModel.getBarnAge(it) } ?: 15
    
    // Standard target temperature by chick age
    val idealTemp = when {
        selectedAge <= 3 -> 33.0f
        selectedAge <= 7 -> 30.0f
        selectedAge <= 14 -> 27.0f
        selectedAge <= 21 -> 24.0f
        else -> 21.5f
    }
    
    val currentTemp = barnSimTemps[selectedBarnIdSim] ?: idealTemp
    val currentHumidity = barnSimHumidities[selectedBarnIdSim] ?: 62.0f
    
    // Auto-regulation logic
    val isFanActive = if (autoRegulateIoT) {
        currentTemp > (idealTemp + 1.0f)
    } else {
        manualFanOn
    }
    
    val isHeaterActive = if (autoRegulateIoT) {
        currentTemp < (idealTemp - 1.0f)
    } else {
        manualHeaterOn
    }
    
    val isCoolingPadActive = if (autoRegulateIoT) {
        currentTemp > (idealTemp + 2.0f) && currentHumidity < 70.0f
    } else {
        manualCoolingOn
    }
    
    val isFeederActive = if (autoRegulateIoT) {
        true
    } else {
        manualFeederOn
    }

    val liveCount = selectedBarn?.let { viewModel.getBarnLiveCount(it, records) } ?: 8500
    val intakePerBird = when {
        selectedAge <= 7 -> 30.0
        selectedAge <= 14 -> 65.0
        selectedAge <= 21 -> 110.0
        selectedAge <= 28 -> 155.0
        else -> 205.0
    }
    val feedConsumedTodaySim = (liveCount * intakePerBird) / 1000.0 // in Kg

    val onModifyTempSim: (Float) -> Unit = { diff ->
        val newMap = barnSimTemps.toMutableMap()
        newMap[selectedBarnIdSim] = currentTemp + diff
        barnSimTemps = newMap
    }
    
    val onModifyHumidSim: (Float) -> Unit = { diff ->
        val newMap = barnSimHumidities.toMutableMap()
        newMap[selectedBarnIdSim] = (currentHumidity + diff).coerceIn(20f, 95f)
        barnSimHumidities = newMap
    }
    
    val totalChicks = barns.sumOf { it.startingChicks }
    
    // Dynamically calculate active live birds
    val totalDead = records.sumOf { it.mortalityMorning + it.mortalityEvening }
    val totalSold = records.sumOf { it.soldQty }
    val totalInt = records.sumOf { it.domesticQty }
    val totalCul = records.sumOf { it.culledQty }
    val liveBirdsCount = (totalChicks - totalDead - totalSold - totalInt - totalCul).coerceAtLeast(0)
    
    val avgMortalityRate = if (totalChicks > 0) {
        (totalDead.toDouble() / totalChicks.toDouble()) * 100.0
    } else 0.0

    // Average FCR across active barns
    val activeBarnsFCR = barns.map { barn ->
        viewModel.calculateBarnFCR(barn, records, weights)
    }.filter { it > 0.0 }
    val overallFCR = if (activeBarnsFCR.isNotEmpty()) activeBarnsFCR.average() else 1.62

    // Stock feed values
    val starterStock = stock.find { it.name.contains("بادئ") || it.name.contains("Starter") }?.currentBalance ?: 0.0
    val growerStock = stock.find { it.name.contains("نامي") || it.name.contains("Grower") }?.currentBalance ?: 0.0
    val finisherStock = stock.find { it.name.contains("ناهي") || it.name.contains("Finisher") }?.currentBalance ?: 0.0
    val totalFeedStock = starterStock + growerStock + finisherStock

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Developer Header
        Card(
            modifier = Modifier.fillMaxWidth().testTag("dev_box_dashboard"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warehouse,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Column {
                        Text(
                            text = if (isAr) "مؤسسة الموسلي لتجارة الدواجن" else "Al-Musli Poultry Trading Est.",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isAr) "مزارع دجاج اللاحم الذكية" else "Broiler Smart Farms Layout",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isAr) "تطوير د.ضيف الله الحسني" else "Developed by Dr. Dhaifallah Al-Hasani",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE65100)
                        )
                    }
                }
            }
        }

        // Active Alerts Section
        if (alerts.any { !it.isRead }) {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("dashboard_notifications"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isAr) "تنبيهات حرجة نشطة (${alerts.count { !it.isRead }})" else "Active Warnings (${alerts.count { !it.isRead }})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        TextButton(onClick = { viewModel.markAllAlertsAsRead() }) {
                            Text(
                                text = if (isAr) "قراءة الكل" else "Dismiss All",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    alerts.filter { !it.isRead }.take(2).forEach { alert ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { viewModel.markAlertAsRead(alert.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(MaterialTheme.colorScheme.error)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = alert.message,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Dismiss",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Live KPI Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            KpiCard(
                title = if (isAr) "إجمالي الطيور الحية" else "Active Live Flock",
                value = String.format("%,d", liveBirdsCount),
                unit = if (isAr) "طائر" else "chicken",
                icon = Icons.Default.Coronavirus,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = if (isAr) "النفوق التراكمي" else "Cumulative Mortality",
                value = String.format("%.2f", avgMortalityRate),
                unit = "%",
                icon = Icons.Default.Analytics,
                color = if (avgMortalityRate > 5.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            KpiCard(
                title = if (isAr) "معامل التحويل (FCR)" else "Feed Conv. Ratio",
                value = String.format("%.2f", overallFCR),
                unit = if (isAr) "علف/وزن" else "FCR",
                icon = Icons.Default.TrendingUp,
                color = if (overallFCR > 1.8) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = if (isAr) "مخزون العلف الحالي" else "Total Feed Stock",
                value = String.format("%,.0f", totalFeedStock),
                unit = if (isAr) "كجم" else "Kg",
                icon = Icons.Default.Layers,
                color = if (totalFeedStock < 1000.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.weight(1f)
            )
        }

        // Automated IoT Climate Control & Smart Sensors Section
        Text(
            text = if (isAr) "التحكم البيئي والـ IoT المؤتمت" else "Automated Environment & IoT Sensors",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Card(
            modifier = Modifier.fillMaxWidth().testTag("iot_panel_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Header of IoT Panel
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFE65100).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isAr) "مراقبة الحساسات والتحكم الآلي للبيئة" else "Climate Sensor Feeds & Automation",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isAr) "نظام تهوية، تبريد وتغذية ذكي مستمر لضمان أعلى سلامة للقطيع" else "Smart continuous airflow, cooling & automatic feeding to maximize livability",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Barn Selector Tab Row for IoT
                if (barns.isNotEmpty()) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        barns.forEach { b ->
                            val isSelected = selectedBarnIdSim == b.id
                            Card(
                                modifier = Modifier
                                    .clickable { selectedBarnIdSim = b.id }
                                    .testTag("iot_barn_chip_${b.id}"),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = b.code,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = if (isAr) "عنبر تجريبي (في انتظار تسكين عنبر حقيقي)" else "Simulated Barn (Awaiting first chick housing)",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(8.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 2x2 Grid of Key Automated Metrics (Temperature, Humidity, Feed, Water)
                // Row 1: Temperature & Humidity
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Temperature Card
                    SensorMetricCard(
                        title = if (isAr) "درجة الحرارة" else "Barn Temperature",
                        value = String.format("%.1f°C", currentTemp),
                        statusText = if (currentTemp > idealTemp + 1f) {
                            if (isAr) "مرتفعة (+ مروحة)" else "High (Fan ON)"
                        } else if (currentTemp < idealTemp - 1f) {
                            if (isAr) "منخفضة (+ دفاي)" else "Low (Heater ON)"
                        } else {
                            if (isAr) "مثالية (مستقر)" else "Ideal (Normal)"
                        },
                        statusColor = if (currentTemp > idealTemp + 1f || currentTemp < idealTemp - 1f) {
                            Color(0xFFE65100)
                        } else {
                            Color(0xFF2E7D32)
                        },
                        icon = Icons.Default.Thermostat,
                        modifier = Modifier.weight(1f)
                    )

                    // Humidity Card
                    SensorMetricCard(
                        title = if (isAr) "الرطوبة النسبية" else "Relative Humidity",
                        value = String.format("%.1f%%", currentHumidity),
                        statusText = if (currentHumidity > 70.0f) {
                            if (isAr) "رطبة جداً" else "Too Humid"
                        } else if (currentHumidity < 45.0f) {
                            if (isAr) "جافة" else "Too Dry"
                        } else {
                            if (isAr) "مثالية (مريحة)" else "Optimal (Ideal)"
                        },
                        statusColor = if (currentHumidity > 70.0f || currentHumidity < 45.0f) {
                            Color(0xFFF9A825)
                        } else {
                            Color(0xFF00ACC1)
                        },
                        icon = Icons.Default.Opacity,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: Automated Feed Dispenser & Water Pressure/Flow
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Feed Consumption Card
                    SensorMetricCard(
                        title = if (isAr) "التغذية الآلية اليومية" else "Auto-Feed Dispensed",
                        value = String.format("%,.0f كجم", feedConsumedTodaySim),
                        statusText = if (isFeederActive) {
                            if (isAr) "جاري التغذية آلياً" else "Line: Feeding"
                        } else {
                            if (isAr) "خط التغذية مغلق" else "Feeder: Standby"
                        },
                        statusColor = if (isFeederActive) Color(0xFF2E7D32) else Color(0xFF757575),
                        icon = Icons.Default.Grain,
                        modifier = Modifier.weight(1f)
                    )

                    // Water Card
                    SensorMetricCard(
                        title = if (isAr) "سريان وضغط المياه" else "Drinking Water Line",
                        value = String.format("%.1f لتر/د" , 12.5f + (currentTemp * 0.4f)),
                        statusText = if (isAr) "ضغط النبل 1.8 بار" else "Line Pres: 1.8 Bar",
                        statusColor = Color(0xFF0288D1),
                        icon = Icons.Default.Speed,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Interactive Adjusters (Buttons to change temperature and humidity)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (isAr) "محاكي الظروف البيئية للعنبر (اختبار الأتمتة)" else "Environmental Sandbox (Test Automation Features)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onModifyTempSim(-1.0f) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), contentColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isAr) "تبريد (-1°م)" else "Cool (-1°C)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onModifyTempSim(1.0f) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.08f), contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isAr) "تسخين (+1°م)" else "Heat (+1°C)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                // Automation Mode Select and Accessory Switches
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isAr) "التحكم البيئي التلقائي (أتمتة)" else "Smart Auto-Regulation Mode",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (autoRegulateIoT) {
                                    if (isAr) "الحاسوب ينظم التدفئة والتهوية تلقائياً" else "System is auto-regulating climate based on target guide"
                                } else {
                                    if (isAr) "تحكم يدوي كامل من المشغل" else "Manual override active (operator settings)"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (autoRegulateIoT) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = autoRegulateIoT,
                            onCheckedChange = { autoRegulateIoT = it },
                            modifier = Modifier.testTag("iot_autog_switch")
                        )
                    }

                    // Simulated Accessories Status Indicators / Switches
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Fan accessory box
                        AccessoryStatusBox(
                            name = if (isAr) "مراوح السحب" else "Exhaust Fans",
                            isActive = isFanActive,
                            isAuto = autoRegulateIoT,
                            manualChecked = manualFanOn,
                            onManualChange = { manualFanOn = it },
                            modifier = Modifier.weight(1f)
                        )

                        // Cooling Pads accessory box
                        AccessoryStatusBox(
                            name = if (isAr) "خلايا التبريد" else "Cooling Pads",
                            isActive = isCoolingPadActive,
                            isAuto = autoRegulateIoT,
                            manualChecked = manualCoolingOn,
                            onManualChange = { manualCoolingOn = it },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Heater accessory box
                        AccessoryStatusBox(
                            name = if (isAr) "التدفئة والغاز" else "Heaters",
                            isActive = isHeaterActive,
                            isAuto = autoRegulateIoT,
                            manualChecked = manualHeaterOn,
                            onManualChange = { manualHeaterOn = it },
                            modifier = Modifier.weight(1f)
                        )

                        // Feeder accessory box
                        AccessoryStatusBox(
                            name = if (isAr) "خطوط التعليف" else "Feeders Line",
                            isActive = isFeederActive,
                            isAuto = autoRegulateIoT,
                            manualChecked = manualFeederOn,
                            onManualChange = { manualFeederOn = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Analytical Charts block
        Text(
            text = if (isAr) "مخططات ومؤشرات الأداء" else "Analytical Performance Charts",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isAr) "تطور استهلاك العلف اليومي (آخر 10 أيام)" else "Daily Feed Consumption (Last 10 Days)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                // Draw Feed Consumption Chart using Canvas dynamically
                val feedValues = records.take(10).reversed().map { it.feedMorningQty + it.feedEveningQty }
                if (feedValues.isNotEmpty()) {
                    CustomLineChart(
                        data = feedValues,
                        accentColor = MaterialTheme.colorScheme.primary,
                        heightDp = 180,
                        unit = if (isAr) "كجم" else "Kg"
                    )
                } else {
                    EmptyChartPlaceholder(isAr)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isAr) "منحنى النفوق اليومي" else "Flock Mortality Rate Line",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                val mortValues = records.take(10).reversed().map { (it.mortalityMorning + it.mortalityEvening).toDouble() }
                if (mortValues.isNotEmpty()) {
                    CustomLineChart(
                        data = mortValues,
                        accentColor = MaterialTheme.colorScheme.error,
                        heightDp = 180,
                        unit = if (isAr) "نافق" else "birds"
                    )
                } else {
                    EmptyChartPlaceholder(isAr)
                }
            }
        }

        // Active Barns Quick List
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "حالة العنابر المفتوحة" else "Active Barns Surveillance",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            TextButton(onClick = { onNavigateToSection("barns") }) {
                Text(text = if (isAr) "عرض الكل" else "View All")
            }
        }

        if (barns.isEmpty()) {
            Text(
                text = if (isAr) "لا توجد عنابر مسجلة حالياً." else "No barns registered.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(barns) { barn ->
                    val age = viewModel.getBarnAge(barn)
                    val mortality = viewModel.getBarnMortalityRate(barn, records)
                    val liveCount = viewModel.getBarnLiveCount(barn, records)
                    val fcr = viewModel.calculateBarnFCR(barn, records, weights)
                    
                    Card(
                        modifier = Modifier
                            .width(180.dp)
                            .clickable { onNavigateToSection("barns") },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = barn.code,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isAr) "السلالة: ${barn.breedType}" else "Breed: ${barn.breedType}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isAr) "العمر: $age يوم" else "Age: $age days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Divider(modifier = Modifier.padding(vertical = 6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isAr) "العدد الحقيقي" else "Live count",
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    text = "$liveCount",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "FCR",
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    text = String.format("%.2f", fcr),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Start
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
        }
    }
}

@Composable
fun CustomLineChart(
    data: List<Double>,
    accentColor: Color,
    heightDp: Int = 180,
    unit: String = ""
) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .padding(top = 16.dp, bottom = 16.dp, start = 8.dp, end = 8.dp)
    ) {
        val maxValue = data.maxOrNull()?.let { if (it <= 0) 1.0 else it } ?: 1.0
        val minValue = 0.0
        val valueRange = maxValue - minValue

        val paddingOffset = 15f
        val usableWidth = size.width - 2 * paddingOffset
        val usableHeight = size.height - 2 * paddingOffset

        val points = data.mapIndexed { idx, value ->
            val fractionX = if (data.size > 1) idx.toFloat() / (data.size - 1) else 0.5f
            val fractionY = ((value - minValue) / valueRange).toFloat()
            Offset(
                x = paddingOffset + fractionX * usableWidth,
                y = paddingOffset + (1f - fractionY) * usableHeight
            )
        }

        // Draw gridlines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = paddingOffset + (i.toFloat() / gridLines) * usableHeight
            drawLine(
                color = Color.LightGray.copy(alpha = 0.3f),
                start = Offset(paddingOffset, y),
                end = Offset(size.width - paddingOffset, y),
                strokeWidth = 2f
            )
        }

        // Draw smooth path
        if (points.isNotEmpty()) {
            val strokePath = Path().apply {
                if (points.size > 1) {
                    moveTo(points.first().x, points.first().y)
                    for (i in 1..points.lastIndex) {
                        val prevPoint = points[i - 1]
                        val currPoint = points[i]
                        val controlPoint1 = Offset((prevPoint.x + currPoint.x) / 2u.toFloat(), prevPoint.y)
                        val controlPoint2 = Offset((prevPoint.x + currPoint.x) / 2u.toFloat(), currPoint.y)
                        cubicTo(controlPoint1.x, controlPoint1.y, controlPoint2.x, controlPoint2.y, currPoint.x, currPoint.y)
                    }
                } else {
                    moveTo(paddingOffset, size.height / 2f)
                    lineTo(size.width - paddingOffset, size.height / 2f)
                }
            }

            drawPath(
                path = strokePath,
                color = accentColor,
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )

            // Draw shadow gradient underneath line
            val fillPath = Path().apply {
                addPath(strokePath)
                if (points.size > 1) {
                    lineTo(points.last().x, size.height - paddingOffset)
                    lineTo(points.first().x, size.height - paddingOffset)
                    close()
                }
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(accentColor.copy(alpha = 0.25f), Color.Transparent)
                )
            )

            // Draw points dots
            points.forEachIndexed { i, pt ->
                drawCircle(
                    color = Color.White,
                    radius = 10f,
                    center = pt
                )
                drawCircle(
                    color = accentColor,
                    radius = 6f,
                    center = pt
                )
            }
        }
    }
}

@Composable
fun EmptyChartPlaceholder(isAr: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(Color.Gray.copy(alpha = 0.05f), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Timeline,
                contentDescription = null,
                tint = Color.LightGray,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isAr) "بانتظار إدخال السجلات المقارنة لتغذية المنحنى البياني..." else "Awaiting daily logs to plot the graph...",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun SensorMetricCard(
    title: String,
    value: String,
    statusText: String,
    statusColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.testTag("sensor_metric_" + title.replace(" ", "_").lowercase()),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(statusColor.copy(alpha = 0.08f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AccessoryStatusBox(
    name: String,
    isActive: Boolean,
    isAuto: Boolean,
    manualChecked: Boolean,
    onManualChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val clickableModifier = if (!isAuto) {
        Modifier.clickable { onManualChange(!manualChecked) }
    } else {
        Modifier
    }

    Card(
        modifier = modifier
            .then(clickableModifier)
            .testTag("acc_box_" + name.replace(" ", "_").replace("أ", "ا").lowercase()),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
            }
        ),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (isActive) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isActive) Color(0xFF2E7D32) else Color(0xFF9E9E9E))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isActive) {
                            "ACTIVE"
                        } else {
                            "STANDBY"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        color = if (isActive) Color(0xFF2E7D32) else Color(0xFF757575)
                    )
                }
            }
            if (!isAuto) {
                Checkbox(
                    checked = manualChecked,
                    onCheckedChange = onManualChange,
                    modifier = Modifier.testTag("check_" + name.replace(" ", "_").lowercase())
                )
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "AUTO",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
