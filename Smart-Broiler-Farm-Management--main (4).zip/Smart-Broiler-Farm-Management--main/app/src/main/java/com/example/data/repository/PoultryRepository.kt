package com.example.data.repository

import com.example.data.database.PoultryDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.*

class PoultryRepository(private val poultryDao: PoultryDao) {

    // Barns
    val allBarns: Flow<List<Barn>> = poultryDao.getAllBarns()

    suspend fun getBarnById(id: Long): Barn? = poultryDao.getBarnById(id)

    suspend fun insertBarn(barn: Barn): Long {
        val result = poultryDao.insertBarn(barn)
        // Ensure standard stock item alerts or setup are checked
        return result
    }

    suspend fun updateBarn(barn: Barn) = poultryDao.updateBarn(barn)

    suspend fun deleteBarn(barn: Barn) = poultryDao.deleteBarn(barn)

    // Daily Records
    val allDailyRecords: Flow<List<DailyRecord>> = poultryDao.getAllDailyRecords()

    fun getDailyRecordsForBarn(barnId: Long): Flow<List<DailyRecord>> =
        poultryDao.getDailyRecordsForBarn(barnId)

    suspend fun insertDailyRecord(record: DailyRecord): Long {
        val id = poultryDao.insertDailyRecord(record)
        
        // Find associated barn
        val barn = poultryDao.getBarnById(record.barnId) ?: return id
        
        // --- 1. Automatic Stock Deduction ---
        val totalFeedConsumed = record.feedMorningQty + record.feedEveningQty
        if (totalFeedConsumed > 0.0) {
            // Determine feed type based on age
            val feedType = when {
                record.ageDays <= 15 -> "علف بادئ (Starter)"
                record.ageDays <= 30 -> "علف نامي (Grower)"
                else -> "علف ناهي (Finisher)"
            }

            val stockItem = poultryDao.getStockItemByName(feedType)
            if (stockItem != null) {
                val newBalance = (stockItem.currentBalance - totalFeedConsumed).coerceAtLeast(0.0)
                poultryDao.insertStockItem(stockItem.copy(currentBalance = newBalance))
                
                // Log Stock Transaction
                poultryDao.insertStockTransaction(
                    StockTransaction(
                        itemName = feedType,
                        type = "OUT",
                        quantity = totalFeedConsumed,
                        date = record.date,
                        notes = "صرف تلقائي - عنبر ${barn.code} - عمر ${record.ageDays} يوم"
                    )
                )

                // High-intelligence: low stock warning
                if (newBalance <= stockItem.minLimit) {
                    poultryDao.insertAlert(
                        Alert(
                            barnId = barn.id,
                            title = "تنبيه اقتراب نفاد المخزون",
                            message = "مخزون الصنف [${feedType}] منخفض جداً: ${String.format("%.2f", newBalance)} ${stockItem.unit} (الحد الأدنى: ${stockItem.minLimit})",
                            date = record.date,
                            severity = "WARNING"
                        )
                    )
                }
            }
        }

        // --- 2. Intelligent Alerts & Anomaly Detection ---
        val totalTodayDead = record.mortalityMorning + record.mortalityEvening
        if (totalTodayDead > 0) {
            // Calculate today's mortality rate
            val starting = barn.startingChicks
            val todayMortalityPercent = (totalTodayDead.toDouble() / starting.toDouble()) * 100.0
            
            if (todayMortalityPercent > 0.5) {
                poultryDao.insertAlert(
                    Alert(
                        barnId = barn.id,
                        title = "تنبيه: نفوق يومي مرتفع",
                        message = "تم تسجيل معدل نفوق يومي غير طبيعي في عنبر ${barn.code}: ${totalTodayDead} طائر (${String.format("%.2f", todayMortalityPercent)}%) في عمر ${record.ageDays} يوم.",
                        date = record.date,
                        severity = "WARNING"
                    )
                )
            }
        }

        // Check for cumulative mortality in the barn > 5% as requested: "تنبيه: إذا النفوق > 5%"
        val records = poultryDao.getDailyRecordsForBarn(barn.id).firstOrNull() ?: emptyList()
        val totalDeadCumulative = records.sumOf { it.mortalityMorning + it.mortalityEvening } + totalTodayDead
        val cumulativeMortalityPercent = (totalDeadCumulative.toDouble() / barn.startingChicks.toDouble()) * 100.0
        if (cumulativeMortalityPercent > 5.0) {
            poultryDao.insertAlert(
                Alert(
                    barnId = barn.id,
                    title = "تحذير: نفوق إجمالي حرج",
                    message = "النفوق التراكمي لعنبر ${barn.code} تجاوز العتبة الآمنة (5%): ${totalDeadCumulative} طائر نافق بنسبة ${String.format("%.2f", cumulativeMortalityPercent)}% منذ بداية الدورة.",
                    date = record.date,
                    severity = "CRITICAL"
                )
            )
        }

        // Check feed reduction anomaly: "تنبيه عند انخفاض استهلاك العلف / كشف القيم الشاذة"
        // Let's look at the previous record of this barn
        if (records.isNotEmpty()) {
            val lastRecord = records.first() // It is sorted by date DESC, so this is the latest in DB
            val prevFeed = lastRecord.feedMorningQty + lastRecord.feedEveningQty
            if (prevFeed > 0.0 && totalFeedConsumed > 0.0) {
                val feedReduction = (prevFeed - totalFeedConsumed) / prevFeed * 100.0
                if (feedReduction > 20.0) { // drop in feed intake of more than 20% is abnormal
                    poultryDao.insertAlert(
                        Alert(
                            barnId = barn.id,
                            title = "تنبيه: انخفاض حاد في استهلاك العلف",
                            message = "هناك انخفاض مفاجئ وشاذ في استهلاك العلف بنسبة ${String.format("%.1f", feedReduction)}% في عنبر ${barn.code} (اليوم: ${totalFeedConsumed} كجم، السابق: ${prevFeed} كجم). قد يشير ذلك لإصابة مرضية أو مشكلة تهوية.",
                            date = record.date,
                            severity = "CRITICAL"
                        )
                    )
                }
            }
        }

        return id
    }

    suspend fun deleteDailyRecord(record: DailyRecord) {
        poultryDao.deleteDailyRecord(record)
        // If daily record deleted, maybe we could restore stock, but let's keep it simple
    }

    // Stock
    val stockItems: Flow<List<StockItem>> = poultryDao.getStockItems()
    val stockTransactions: Flow<List<StockTransaction>> = poultryDao.getStockTransactions()

    suspend fun getStockItemByName(name: String): StockItem? = poultryDao.getStockItemByName(name)

    suspend fun insertStockItem(item: StockItem) = poultryDao.insertStockItem(item)

    suspend fun addStockTransaction(itemName: String, type: String, quantity: Double, notes: String): Long {
        val stockItem = poultryDao.getStockItemByName(itemName)
        if (stockItem != null) {
            val newBalance = if (type == "IN") {
                stockItem.currentBalance + quantity
            } else {
                (stockItem.currentBalance - quantity).coerceAtLeast(0.0)
            }
            poultryDao.insertStockItem(stockItem.copy(currentBalance = newBalance))
        } else {
            // If doesn't exist, create it
            poultryDao.insertStockItem(StockItem(name = itemName, currentBalance = quantity, unit = "Kg", minLimit = 100.0))
        }

        val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateStr = df.format(Date())

        return poultryDao.insertStockTransaction(
            StockTransaction(
                itemName = itemName,
                type = type,
                quantity = quantity,
                date = dateStr,
                notes = notes
            )
        )
    }

    // Weekly Weights
    val allWeightSamples: Flow<List<WeightSample>> = poultryDao.getAllWeightSamples()

    fun getWeightSamplesForBarn(barnId: Long): Flow<List<WeightSample>> =
        poultryDao.getWeightSamplesForBarn(barnId)

    suspend fun insertWeightSample(sample: WeightSample): Long {
        val id = poultryDao.insertWeightSample(sample)
        
        // Intelligent comparison Check: "تنبيه: إذا الوزن أقل من المعيار"
        val barn = poultryDao.getBarnById(sample.barnId)
        if (barn != null) {
            // Let's find breed standards
            val standard = PoultryScience.breeds.find { it.name.lowercase() == barn.breedType.lowercase() }
                ?: PoultryScience.breeds.first()
            
            val weekIndex = sample.weekNumber.coerceIn(0, standard.targetWeights.lastIndex)
            val standardWeight = standard.targetWeights[weekIndex]
            if (sample.averageWeight < standardWeight * 0.9) { // 10% below standard is alert-worthy
                poultryDao.insertAlert(
                    Alert(
                        barnId = barn.id,
                        title = "تنبيه: نمو أقل من المعيار القياسي",
                        message = "متوسط الوزن الأسبوعي للأسوع ${sample.weekNumber} في عنبر ${barn.code} هو (${sample.averageWeight} جم)، وهو أقل بنسبة تزيد عن 10% من معايير سلالة ${barn.breedType} (${standardWeight} جم).",
                        date = sample.date,
                        severity = "WARNING"
                    )
                )
            }
        }
        return id
    }

    // Alerts
    val unreadAlerts: Flow<List<Alert>> = poultryDao.getUnreadAlerts()
    val allAlerts: Flow<List<Alert>> = poultryDao.getAllAlerts()

    suspend fun markAlertAsRead(id: Long) = poultryDao.markAlertAsRead(id)
    suspend fun markAllAlertsAsRead() = poultryDao.markAllAlertsAsRead()
    suspend fun insertAlert(alert: Alert) = poultryDao.insertAlert(alert)

    // Expenses
    val allExpenses: Flow<List<Expense>> = poultryDao.getAllExpenses()

    fun getExpensesForBarn(barnId: Long): Flow<List<Expense>> =
        poultryDao.getExpensesForBarn(barnId)

    suspend fun insertExpense(expense: Expense): Long = poultryDao.insertExpense(expense)

    suspend fun deleteExpense(expense: Expense) = poultryDao.deleteExpense(expense)

    // Database Seeding
    suspend fun seedDatabaseIfEmpty() {
        // Run check on barns
        val barns = poultryDao.getAllBarns().firstOrNull()
        if (barns.isNullOrEmpty()) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_YEAR, -20) // Seed database with cycle that started 20 days ago
            val startDateStr = sdf.format(calendar.time)

            // 1. Create Default 4 Barns
            val b1 = poultryDao.insertBarn(Barn(code = "عنبر أ (العنبر الشمالي)", capacity = 10000, startingChicks = 10000, startDate = startDateStr, breedType = "Ross 308"))
            val b2 = poultryDao.insertBarn(Barn(code = "عنبر ب (العنبر الجنوبي)", capacity = 12000, startingChicks = 12000, startDate = startDateStr, breedType = "Cobb 500"))
            val b3 = poultryDao.insertBarn(Barn(code = "عنبر ج (العنبر الشرقي)", capacity = 10000, startingChicks = 10000, startDate = startDateStr, breedType = "Indian River"))
            val b4 = poultryDao.insertBarn(Barn(code = "عنبر د (العنبر الغربي)", capacity = 15000, startingChicks = 15000, startDate = startDateStr, breedType = "Ross 308"))

            // 2. Seed default stocks
            poultryDao.insertStockItem(StockItem("علف بادئ (Starter)", 5000.0, "كجم", 1000.0))
            poultryDao.insertStockItem(StockItem("علف نامي (Grower)", 8000.0, "كجم", 1500.0))
            poultryDao.insertStockItem(StockItem("علف ناهي (Finisher)", 10000.0, "كجم", 2000.0))
            poultryDao.insertStockItem(StockItem("نشارة خشب (Wood Shavings)", 250.0, "كيس", 50.0))
            poultryDao.insertStockItem(StockItem("مضادات حيوية ومطهرات (Medicines)", 45.0, "زجاجة", 10.0))
            poultryDao.insertStockItem(StockItem("فيتامينات ومكملات غذائية (Vitamins)", 60.0, "عبوة", 15.0))

            // 3. Seed some historical records for barn A to demonstrate dynamic analytical success
            val recordDate = Calendar.getInstance()
            recordDate.time = calendar.time
            var currentLiveA = 10000
            for (day in 1..20) {
                val dateStr = sdf.format(recordDate.time)
                // daily mortalities
                val mortMor = if (day == 14) 20 else if (day == 3) 5 else (0..2).random()
                val mortEve = if (day == 14) 35 else (0..2).random() // day 14 gumboro peak is simulated under day 14!
                currentLiveA -= (mortMor + mortEve)

                // feed intake (average broiler feed scale: day 1: 15g... day 20: 100g per bird)
                val intakePerBirdKg = (12 + day * 4.5) / 1000.0
                val totalFeedForDay = currentLiveA * intakePerBirdKg
                val feedMor = totalFeedForDay * 0.45
                val feedEve = totalFeedForDay * 0.55

                // water scale: water is typically 1.8 to 2 times feed
                val waterLit = totalFeedForDay * 1.8

                poultryDao.insertDailyRecord(
                    DailyRecord(
                        barnId = b1,
                        date = dateStr,
                        ageDays = day,
                        feedMorningQty = feedMor,
                        feedEveningQty = feedEve,
                        waterQty = waterLit,
                        mortalityMorning = mortMor,
                        mortalityEvening = mortEve,
                        soldQty = 0,
                        domesticQty = 0,
                        culledQty = 0
                    )
                )

                // Let's add expenses
                if (day == 1) {
                    poultryDao.insertExpense(Expense(barnId = b1, date = dateStr, category = "النشارة", amount = 1500.0, notes = "شراء وفرش نشارة أول الدورة"))
                }
                // add daily water or fuel/electricity costs
                poultryDao.insertExpense(Expense(barnId = b1, date = dateStr, category = "كهرباء ومياه", amount = 50.0, notes = "تشغيل شفاطات وتدفئة مكرر يومي"))

                recordDate.add(Calendar.DAY_OF_YEAR, 1)
            }

            // Seed weekly weights for Barn A
            poultryDao.insertWeightSample(WeightSample(barnId = b1, date = sdf.format(calendar.time), weekNumber = 1, averageWeight = 192.0, uniformity = 88.0, standardDeviation = 15.0))
            calendar.add(Calendar.DAY_OF_YEAR, 7)
            poultryDao.insertWeightSample(WeightSample(barnId = b1, date = sdf.format(calendar.time), weekNumber = 2, averageWeight = 478.0, uniformity = 90.0, standardDeviation = 35.0))

            // Seed an initial alert about Day 14 mortality spike to make UI look amazing and responsive on launch
            poultryDao.insertAlert(
                Alert(
                    barnId = b1,
                    title = "تنبيه: نفوق مرتفع يوم 14",
                    message = "تم تسجيل 55 نافقاً في عنبر أ (العنبر الشمالي) في عمر 14 يوم نتيجة اشتباه إصابة الجمبورو.",
                    date = sdf.format(calendar.time),
                    severity = "CRITICAL"
                )
            )
        }
    }
}
