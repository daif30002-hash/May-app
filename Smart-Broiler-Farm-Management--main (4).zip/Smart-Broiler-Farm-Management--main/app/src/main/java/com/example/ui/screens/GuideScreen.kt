package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.repository.DiseaseInfo
import com.example.data.repository.PoultryScience
import com.example.data.repository.VaccineScheduleItem
import com.example.ui.viewmodel.PoultryViewModel

@Composable
fun GuideScreen(
    viewModel: PoultryViewModel
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    var selectedDisease by remember { mutableStateOf<DiseaseInfo?>(null) }
    var activeSubTab by remember { mutableStateOf(0) } // 0 = Diseases Guide, 1 = Vaccination Schedule, 2 = Biosecurity Checklist

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("guide_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = if (isAr) "الدليل الطبي والوقائي الذكي" else "Veterinary Medical & Biosecurity Guide",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (isAr) "الأمراض، الأدوية، التحصينات والأمن الحيوي - د.ضيف الله الحسني" else "Diseases, treatments, dosing ratios & schedules",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Sub TAB Control
        TabRow(selectedTabIndex = activeSubTab) {
            Tab(selected = activeSubTab == 0, onClick = { activeSubTab = 0 }) {
                Text(text = if (isAr) "أمراض التسمين" else "Diseases Index", modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeSubTab == 1, onClick = { activeSubTab = 1 }) {
                Text(text = if (isAr) "جدول التحصينات" else "Vaccines", modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeSubTab == 2, onClick = { activeSubTab = 2 }) {
                Text(text = if (isAr) "الأمن الوقائي" else "Biosecurity", modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
            }
        }

        when (activeSubTab) {
            0 -> {
                // Diseases Index list
                if (selectedDisease == null) {
                    Text(
                        text = if (isAr) "اختر مرضاً لتفاصيل الجرعات والتشخيص الفوري:" else "Browse broiler health threats (1-45 days):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(PoultryScience.diseases) { disease ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedDisease = disease },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isAr) disease.nameAr else disease.nameEn,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${if (isAr) "العمر المستهدف:" else "Age span:"} ${disease.ageRange}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(Icons.Default.MedicalServices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                } else {
                    // Disease Detailed card view
                    val d = selectedDisease!!
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isAr) d.nameAr else d.nameEn,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = { selectedDisease = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Back")
                            }
                        }

                        DetailSection(
                            title = if (isAr) "العمر الشائع للإصابة" else "Common Age Block",
                            content = d.ageRange,
                            icon = Icons.Default.CalendarToday
                        )

                        DetailSection(
                            title = if (isAr) "الأعراض والعلامات التشخيصية" else "Diagnosis & Symptoms",
                            content = if (isAr) d.symptomsAr else d.symptomsEn,
                            icon = Icons.Default.Coronavirus
                        )

                        DetailSection(
                            title = if (isAr) "بروتوكول العلاج والسيطرة" else "Treatment Protocol",
                            content = if (isAr) d.treatmentAr else d.treatmentEn,
                            icon = Icons.Default.Science
                        )

                        // Antibiotics emphasis (highly requested)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Medication, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isAr) "المضاد الحيوي والجرعة الموصى بها:" else "Target Antibiotic & Exact Dose Ratio:",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${if (isAr) "الاسم العلمي:" else "Antibiotic:"} ${if (isAr) d.antibioticAr else d.antibioticEn}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${if (isAr) "الجرعة اليومية:" else "Dosage Ratio:"} ${if (isAr) d.dosageAr else d.dosageEn}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        DetailSection(
                            title = if (isAr) "الوقاية والحد من الانتشار" else "Prevention Guide",
                            content = if (isAr) d.preventionAr else d.preventionEn,
                            icon = Icons.Default.Shield
                        )
                    }
                }
            }
            1 -> {
                // Vaccination Schedule Table
                Text(
                    text = if (isAr) "تفاصيل جدول اللقاحات الأساسية المعتمدة لقطيع التسمين:" else "Crucial vaccine logs & schedules:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(PoultryScience.vaccines) { vaccine ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isAr) "عمر ${vaccine.day} يوم" else "Day ${vaccine.day}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                    
                                    Text(
                                        text = if (isAr) vaccine.nameAr else vaccine.nameEn,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                
                                Divider(modifier = Modifier.padding(vertical = 8.dp))
                                
                                Text(
                                    text = "${if (isAr) "طريقة الإعطاء:" else "Method:"} ${if (isAr) vaccine.methodAr else vaccine.methodEn}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${if (isAr) "ملاحظات إرشادية:" else "Notes:"} ${if (isAr) vaccine.notesAr else vaccine.notesEn}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            2 -> {
                // Biosecurity Checklist Cards
                Text(
                    text = if (isAr) "إجراءات الأمن الحيوي للحد من انتشار الأوبئة والأمراض المعدية:" else "Farm guidelines to stop viral transfers instantly:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                val items = if (isAr) PoultryScience.biosecurityAr else PoultryScience.biosecurityEn
                
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(items) { bio ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = bio,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailSection(
    title: String,
    content: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}
