package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.viewmodel.PoultryViewModel

@Composable
fun StockScreen(
    viewModel: PoultryViewModel,
    stockItems: List<StockItem>,
    transactions: List<StockTransaction>,
    records: List<DailyRecord>,
    expenses: List<Expense>
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isAr = language == "ar"

    var showAdjustStockDialog by remember { mutableStateOf(false) }
    val canModify = viewModel.canInsertOrEdit()

    val totalExpensesValue = expenses.sumOf { it.amount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("stock_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Stock Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isAr) "المخازن والمصاريف الإنتاجية" else "Stock Inventory & Production Costs",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (isAr) "تتبع رصيد الأعلاف، الأدوية، والنشارة وتوقع النقص" else "Feeds, medicines & shavings status",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (canModify) {
                Button(
                    onClick = { showAdjustStockDialog = true },
                    modifier = Modifier.testTag("stock_adjust_btn")
                ) {
                    Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isAr) "توريد جديد" else "Purchase / Stock IN")
                }
            }
        }

        // Section Toggles: Stock / Expenses
        var activeTab by remember { mutableStateOf(0) } // 0 = Stock, 1 = Financial Expenses
        
        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                Text(text = if (isAr) "رصيد المستودعات" else "Stores", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                Text(text = if (isAr) "تكاليف الإنتاج والربحية" else "Expenses & Yield", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
        }

        if (activeTab == 0) {
            // Inventory Cards with Forecast Indicators
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(stockItems) { item ->
                    val forecastDays = viewModel.calculateStockForecastDays(item.name, item, records)
                    val isLow = item.currentBalance <= item.minLimit

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isLow) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, if (isLow) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when {
                                            item.name.contains("علف") -> Icons.Default.Agriculture
                                            item.name.contains("نشارة") -> Icons.Default.Store
                                            item.name.contains("فيتامينات") -> Icons.Default.Medication
                                            else -> Icons.Default.Healing
                                        },
                                        contentDescription = null,
                                        tint = if (isLow) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = item.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                                if (isLow) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.error)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (isAr) "منخفض" else "Crit Low",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onError,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(if (isAr) "الرصيد الحالي" else "Current Stock", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = "${String.format("%,.1f", item.currentBalance)} ${item.unit}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (forecastDays < 5) MaterialTheme.colorScheme.errorContainer 
                                            else MaterialTheme.colorScheme.primaryContainer
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (isAr) "يكفي لـ $forecastDays يوم" else "Safe for $forecastDays days",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (forecastDays < 5) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
                
                // Show History header
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isAr) "سجل المعاملات السابقة وحركات المخزن" else "Store In / Out logged feed",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (transactions.isEmpty()) {
                    item {
                        Text(
                            text = if (isAr) "لم يتم تسجيل أي عمليات توريد لمخزونك للآن" else "No stock transactions recorded yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(transactions) { tx ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (tx.type == "IN") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                    contentDescription = null,
                                    tint = if (tx.type == "IN") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(text = tx.itemName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    Text(text = tx.notes, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${if (tx.type == "IN") "+" else "-"} ${tx.quantity}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (tx.type == "IN") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                                Text(text = tx.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        } else {
            // Production Costs Tracking
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Financial Profitability Status card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isAr) "المصروفات النقدية التشغيلية المؤرشفة" else "Operation Costs Archived",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%,.0f ر.ي", totalExpensesValue),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))
                        Text(
                            text = if (isAr) "تحذير: المصاريف العالية غير المقننة تقلل هامش الربحية الإجمالية للدورة." else "Keeping expenses tightly audited maximizes the flock's profitability margin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Text(
                    text = if (isAr) "تفاصيل فواتير ونفقات الدورة:" else "Detailed expenses ledger:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                if (expenses.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (isAr) "لم يتم تقييد فواتير مالية أو تكاليف للآن." else "No financial expenses registered.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(expenses) { exp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.secondary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = exp.category, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = exp.notes, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${String.format("%,.0f", exp.amount)} ر.ي",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                    Text(text = exp.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Adjust Stock Dialog
    if (showAdjustStockDialog) {
        var selectedItem by remember { mutableStateOf("علف بادئ (Starter)") }
        var type by remember { mutableStateOf("IN") } // "IN" or "OUT"
        var quantity by remember { mutableStateOf("1000.0") }
        var notes by remember { mutableStateOf("فاتورة شراء علف تسمين") }

        val itemsList = listOf(
            "علف بادئ (Starter)",
            "علف نامي (Grower)",
            "علف ناهي (Finisher)",
            "نشارة خشب (Wood Shavings)",
            "مضادات حيوية ومطهرات (Medicines)",
            "فيتامينات ومكملات غذائية (Vitamins)"
        )

        AlertDialog(
            onDismissRequest = { showAdjustStockDialog = false },
            title = { Text(if (isAr) "تسجيل حركة توريد مخزن" else "Stock Transaction Adjustment") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(if (isAr) "اختر الصنف المراد تعديله:" else "Item selector:", style = MaterialTheme.typography.labelMedium)
                    itemsList.forEach { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedItem = item }
                                .padding(vertical = 2.dp)
                        ) {
                            RadioButton(selected = selectedItem == item, onClick = { selectedItem = item })
                            Text(item, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(if (isAr) "نوع الحركة:" else "Action type:", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { type = "IN" }) {
                            RadioButton(selected = type == "IN", onClick = { type = "IN" })
                            Text(if (isAr) "توريد (In)" else "Deposit", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { type = "OUT" }) {
                            RadioButton(selected = type == "OUT", onClick = { type = "OUT" })
                            Text(if (isAr) "صرف يدوي (Out)" else "Withdraw", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text(if (isAr) "الكمية المضافة/المخصومة" else "Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (isAr) "صورة الفاتورة وتفاصيل المورد" else "Receipt & Partner details") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qtyVal = quantity.toDoubleOrNull() ?: 1000.0
                        viewModel.addStockAdjustment(selectedItem, type, qtyVal, notes)
                        showAdjustStockDialog = false
                    }
                ) {
                    Text(if (isAr) "تأكيد وإدخال" else "Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustStockDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }
}
